# AAV prediction
# 30 Sept 2019 
# Outcome: Time to 1st infection: update prediction afte 1 year

###### LIBRARY ######
#####################

library(devtools)
library(caret)
library(prodlim)
library(muhaz)
library(survival)
library(survminer)
library(Hmisc)
library(rms)
library(reshape2)
library(mfp)
library(rstpm2)
library(flexsurv)
library(dplyr)
library(qwraps2)
library(survminer)
library(ggfortify)
library(lsr)
library(ggcorrplot)
library(skimr)
library(purrr)
library(tidyr)
library(nonnestcox)
library(lubridate)

######################

##################################
# Data preparation for infection #
##################################

setwd("H:\\AAVprediction\\Analysis")
load("H:\\AAVprediction\\Analysis\\data_relapse.RData")

# compute time-to-infection in days #
#View(data[,c("time_to_composite_1_serious_or_3_non_serious_m","non_serious_infection_after_RTX",
#             "Serious_infection_after_RTX","third_non_serious_infection")])

# create event indicator#
data$Infection_after_RTX<-ifelse(is.na(data$time_to_composite_1_serious_or_3_non_serious_m),0,1)

data$time.to.infection<-data$time_to_composite_1_serious_or_3_non_serious_m*30 

#censored duration for min(time.to.end of follow-up, time.to.relapse)

data$time.to.infection[is.na(data$time.to.infection)]<-as.numeric(pmin(difftime(dmy(data$Date_of_last_follow_up),
                                                                                dmy(data$Date_last_RTX),
                                                                                unit="days"),data$time.to.relapse))

#View(data[,c("time_to_composite_1_serious_or_3_non_serious_m","time.to.infection","Infection_after_RTX")])

# remove individuals where last follow-up date <= last RTX date #
data<-data[!(data$time.to.infection<0.00001),] # left with 147 IDs
#keep events after 12mons (if there is event) and all censored patients #
# format of time #

a<-data[data$time.to.infection-365>=0,] 
data_12m<-a # left with 122 obs

#View(data[,c("time_to_composite_1_serious_or_3_non_serious_m","time.to.infection","infection_after_RTX")])

table(data_12m$Infection_after_RTX) # 68 events

# remove individuals where last follow-up date <= last RTX date #
data<-data[!(data$time.to.infection<0.00001),] # left with 122 IDs


# make age categorical as a stratification factor #
data_12m[,c("Age_strata","Age_strata_60minus","Age_strata_60plus")]<-NULL
data_12m$Age_strata<- cut(data_12m$Age, 
                      breaks=c(-Inf, 70, Inf), 
                      labels=c("70minus","70plus"))

# need to update time variable #
data_12m$time.to.infection<-data_12m$time.to.infection-365

# shorten covariate names for easy display #
names(data_12m)[26]<-c("Total_lymphocyte_count_at_end_RTX")

# generate number of infections during RTX: infection is defined as 1 serious or 3 non-serious #
data_12m$num_nonseriousinfection_during_RTX<-case_when(as.numeric(data_12m$Number_of_non_serious_infections_during_RTX)-1>2|
                                                         as.numeric(data_12m$Number_of_serious_infections_during_RTX)-1>1 ~ "Infection",
                                                       TRUE ~ "Others") 
table(data_12m$num_nonseriousinfection_during_RTX,data_12m$Infection_after_RTX)

# check correlation between baseline and updated values #
cor(as.numeric(data_12m$IgG_at_12m), as.numeric(data_12m$IgG_at_end_RTX),use="complete.obs") #0.64
cor(as.numeric(data_12m$Lymphocyte_count_at_12m), as.numeric(data_12m$Total_lymphocyte_count_at_end_RTX),use="complete.obs") #0.78


# Prepare summary statistics for table #
summary1 <-
  # categorical #
  list(
    "Gender" =
      list("Female" = ~ qwraps2::n_perc0(.data$Sex=="Female"),
           "Male" = ~ qwraps2::n_perc0(.data$Sex =="Male")),
    "Age_strata" =
      list("70minus" = ~ qwraps2::n_perc0(.data$Age_strata == "70minus"),
           "70plus" = ~ qwraps2::n_perc0(.data$Age_strata == "70plus")),
    "Structural_lung_disease" =
      list("No" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 1)),
    "Diabetes" =
      list("No" = ~ qwraps2::n_perc0(.data$Diabetes == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$Diabetes == 1)),
    "On_antibiotic_prophylaxis_at_end_RTX"=
      list("No" = ~ qwraps2::n_perc0(.data$On_antibiotic_prophylaxis_at_end_RTX == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$On_antibiotic_prophylaxis_at_end_RTX == 1)),
    
    "Number of infections during RTX"=
      list("1+ serious or 3+ non-serious infections" = ~ qwraps2::n_perc0(.data$num_nonseriousinfection_during_RTX=="Infection"),
           "Others" = ~ qwraps2::n_perc0(.data$num_nonseriousinfection_during_RTX=="Others")),
    
    "Cumulative_CYC_before_1st_RTX"=
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_CYC_before_1st_RTX,na_rm = T)),
    
    # This variable has missing values
    "Creatinine at 12m" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Creatinine_at_12m,na_rm = T),
    "Missing"=~ sum(is.na(Creatinine_at_12m))),
    
    "IgG_at_end_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$IgG_at_end_RTX,na_rm = T)),
    
    # This variable has missing values#
    "IgG_at_12m"=
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$IgG_at_12m,na_rm = T,show_n = "never"),
           "Missing"=~ sum(is.na(IgG_at_12m))),
    # This variable has missing values#
    "Lymphocyte_count_at_12m"=
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Lymphocyte_count_at_12m,na_rm = T,
                                                    show_n = "never"),
           "Missing"=~ sum(is.na(Lymphocyte_count_at_12m))),
    # Added variable for paper formatting #
    "Concomitant CYC or oral IS" =
      list("None" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "0"),
           "1+" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "1plus")),
    "Cumulative RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_RTX_g,na_rm = T)),
    "Steroid dose at end RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Steroid_dose_at_end_RTX,na_rm = T)),
    "Creatinine at end RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Creatinine_at_end_RTX,na_rm = T)),
    "Nadir_IgG_during_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Nadir_IgG_during_RTX,na_rm = T)),
    "IgG_at_end_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$IgG_at_end_RTX,na_rm = T)),
    
    # this variable has 4 missing values #
    "Total_lymphocyte_count_at_end_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Total_lymphocyte_count_at_end_RTX,na_rm = T,
                                                    show_n = "never"),
           "Missing"=~ sum(is.na(Total_lymphocyte_count_at_end_RTX)))
    
  )

summary_table1 <- summary_table(data_12m,summary1)
summary_table2 <- summary_table(dplyr::group_by(data_12m, Infection_after_RTX), summary1)
summary_table<-cbind(summary_table1,summary_table2)
capture.output(print(summary_table),file="H:\\AAVprediction\\Analysis\\summary_infection_newpred.txt")


data_12m$Infection_after_RTX<-as.numeric(as.factor(data_12m$Infection_after_RTX)) #2=event

# create a categorical variable for Lym_12m #
# first, missing values on lymphocyte_cout and IgG at 12m were filled by previous values #
data_12m$Lymphocyte_count_at_12m<-as.numeric(data_12m$Lymphocyte_count_at_12m)
data_12m$Lymphocyte_count_at_12m[is.na(data_12m$Lymphocyte_count_at_12m)] <- as.numeric(as.character(
  data_12m$Total_lymphocyte_count_at_end_RTX[is.na(data_12m$Lymphocyte_count_at_12m)]))
data_12m$Lymphocyte_count_at_12mcat<-cut(data_12m$Lymphocyte_count_at_12m,breaks=c(0,1,4),
                                         include.lowest = T,labels = c("1minus","1plus"))

data_12m$IgG_at_12m<-as.numeric(data_12m$IgG_at_12m)
data_12m$IgG_at_12m[is.na(data_12m$IgG_at_12m)]<-as.numeric(as.character(
  data_12m$IgG_at_end_RTX[is.na(data_12m$IgG_at_12m)]))

data_12m<-fastDummies::dummy_cols(data_12m,c("Age_strata","Structural_lung_disease",
                                             "Diabetes","On_antibiotic_prophylaxis_at_end_RTX",
                                             "num_nonseriousinfection_during_RTX",
                                             "ANCA_positive_at_12m","ANCA_positive_at_12m",
                                             "B_cell_return_at_12m","Lymphocyte_count_at_12mcat"))

#  describe time-to-1st infection #
km_infectionnew <- survfit(Surv(time.to.infection/30, Infection_after_RTX==2) ~ 1, data=data_12m)
summary(km_infectionnew)
pdf(file="H:\\AAVprediction\\Analysis\\KM_infection_newpred.pdf")
ggsurvplot(km_infectionnew, data=data_12m,xlab="Time (Months)",palette="Black",risk.table=T)
dev.off()

################
# COX PH model #
################

# add predictors: age strata (to replace raw age, indicator for infection have happened or not before infection
data_12m$Infection_after_RTX<-as.numeric(data_12m$Infection_after_RTX)
table(data_12m$Infection_after_RTX) #2=event


# need to scale continuous predictors #

data2_12m<-data_12m %>% mutate_each_(list(~scale(.,center=T,scale=T) %>% as.vector),
                                     vars=c("Creatinine_at_12m",
                                            "Cumulative_CYC_before_1st_RTX",
                                            "IgG_at_end_RTX",
                                            "IgG_at_12m",
                                            "Lymphocyte_count_at_12m"
                                            ))

# note corr(IgG_at_end_RTX and IgG_at_12m)=0.64 #

# run the model using normalised data #

xpos.infectionnew<-match(c("Sex_Male","Structural_lung_disease_1",
                           "Diabetes_1","num_nonseriousinfection_during_RTX_Infection",
                           "IgG_at_12m",
                           "Lymphocyte_count_at_12m",
                           #"Lymphocyte_count_at_12mcat_1minus",
                           "Creatinine_at_12m"),
                      names(data2_12m))
names(data2_12m)[xpos.infectionnew]

##############################################################################

# Use internal calibration to select the reduced model #
# coxph model #

a<-paste0(paste0(names(data2_12m)[xpos.infectionnew]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)
cox_infectionnew.cph<- cph(as.formula(b), data=data2_12m,x=T,y=T,surv=T,time.inc = 1)
cox_infectionnew.coxph<- coxph(as.formula(b), data=data2_12m)

pdf(file="H:\\AAVprediction\\Analysis\\cox_infectionnewpred.pdf")
ggforest(cox_infectionnew.coxph, data= data2_12m,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()

# Shrinkage & optimism adjusted AUC, CITL etc. using bootstrapping
# with backward variable selection method:
# note: run on data2 due to variable scales for better protection# 
# cox_infection_norm.cph<- cph(as.formula(b), data=data2_12m2,x=T,y=T,surv=T) # this is just backup

boot_results<-matrix(nrow=10,ncol=2)
pos<-1
for (p in c(2,2.5,3,3.5,4,5,6,7,8,9)) {
  set.seed(12345) # to ensure reproducibility
  boot_infection<-validate(cox_infectionnew.cph,method="boot",B=1000,
                           bw=T,rule="p",type="individual",
                           sls=p/10)
  boot_infection<-rbind(c((boot_infection[1,1:3]+1)/2,
                          (boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2,
                          (boot_infection[1,1]+1)/2-((boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2),
                          boot_infection[1,6]),
                        boot_infection)
  rownames(boot_infection)[1]<-"c-index"
  colnames(boot_infection)<-c("Apparent","BS_training","BS_test","Optimism",
                              "Optimism-corrected","rep")
  boot_results[pos,1]<-boot_infection[4,5] # index-corrected slope
  boot_results[pos,2]<-boot_infection[1,5] # index-corrected c-index
  pos<-pos+1
}
boot_results

capture.output(boot_results,file="H:\\AAVprediction\\Analysis\\infectionnew_boot_overall.txt")

# bootstrap for infection: #
set.seed(12345) # to ensure reproducibility
p<-0.35
boot_infection<-validate(cox_infectionnew.cph,method="boot",B=1000,
                         bw=T,rule="p",type="individual",
                         sls=p)
boot_infection<-rbind(c((boot_infection[1,1:3]+1)/2,
                        (boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2,
                        (boot_infection[1,1]+1)/2-((boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2),
                        boot_infection[1,6]),
                      boot_infection)
rownames(boot_infection)[1]<-"c-index"
colnames(boot_infection)<-c("Apparent","BS_training","BS_test","Optimism",
                            "Optimism-corrected","rep")
capture.output(boot_infection,file="H:\\AAVprediction\\Analysis\\infectionnew_reduced_internal.txt")

# retrieved 5 factors in the final model #
xpos.infectionnew<-match(c("Sex_Male","Structural_lung_disease_1",
                        "Diabetes_1","num_nonseriousinfection_during_RTX_Infection",
                        "IgG_at_12m"),
                      names(data2_12m))
names(data2_12m)[xpos.infectionnew]

a<-paste0(paste0(names(data2_12m)[xpos.infectionnew]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)

cox_infectionnew_reduced.coxph<-coxph(as.formula(b), data=data2_12m,x=T)
cox_infectionnew_reduced.cph<-cph(as.formula(b), data=data2_12m,x=T,y=T,surv=T,time.inc=1)

# Test for PH assumption - residual distribution #
cox.zph(cox_infectionnew_reduced.coxph)
pdf(file="H:\\AAVprediction\\Analysis\\cox_infectionnew_reduced_PHtest.pdf")
ggcoxzph(cox.zph(cox_infectionnew_reduced.coxph),font.main=5,font.x=6,font.y=5,
         font.xtickslab=6,font.ytickslab=6)
dev.off()


pdf(file="H:\\AAVprediction\\Analysis\\cox_infectionnew_reduced.pdf")
ggforest(cox_infectionnew_reduced.coxph, data=data2_12m,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()

# Shrink coefficients to improve prediction #
shrinkage.factor<-boot_infection["Slope","Optimism-corrected"]
coef_infectionnew_reduced<- data.frame(Original = coef(cox_infectionnew_reduced.coxph),
                                    Shrunk.BS=c(coef(cox_infectionnew_reduced.coxph) * boot_infection["Slope","Optimism-corrected"]))
capture.output(round(coef_infectionnew_reduced, 3),file="H:\\AAVprediction\\Analysis\\infectionnew_reduced_internal_shrunken.txt")

# PI & C-index for reduced vs shrunk model#
pred_LP <- predict(cox_infectionnew_reduced.coxph,type="lp",reference="sample")
summary(cox_infectionnew_reduced.coxph)$concordance[1]
summary(cox_infectionnew_reduced.coxph)$concordance[1]-(1.96*summary(cox_infectionnew_reduced.coxph)$concordance[2])
summary(cox_infectionnew_reduced.coxph)$concordance[1]+(1.96*summary(cox_infectionnew_reduced.coxph)$concordance[2])
# so apparent c-index= 0.65 [95%CI 0.581, 0.724]

###########################################################
# calibrate the shrunken model (vanH) using bootstrap samples #
# how well is the model at discrimination #
coef_infectionnew_reduced <- tibble::rownames_to_column(coef_infectionnew_reduced,"X")
coef_infectionnew_reduced

# Final model #
# calibrate the final model (horizon=1-6 years,
# present both uncalibrate & calibrated models) #
horizon<-12*seq(1,6,1)

for (i in 1:length(horizon)){
  tempmodel<- cph(cox_infectionnew_reduced.cph$sformula, data=data2_12m,
                  x=T,y=T,surv=T,
                  time.inc=horizon[i])
  
  set.seed(12345) # to ensure reproducibility
  #cal<-calibrate(tempmodel,u=horizon[i],B=1000,maxdim=10) # to add on smoothness
  cali_infection<-calibrate(tempmodel,u=horizon[i],m=122/4,
                            cmethod="KM",method="boot",B=1000)
  fpath<-paste0("H:\\AAVprediction\\Analysis\\calib_infectionnewpred",horizon[i]/12, 
                " yr.pdf")
  pdf(file=fpath)
  lims<-min(attributes(cali_infection)$predicted)
  print(plot(cali_infection,subtitles=F,ylab=paste0("Observed survival (KM)",horizon[i]/12, " years"),   
             xlab=paste0("Predicted survival",horizon[i]/12, " years"),
             xlim=c(0,1),ylim=c(0,1),
             cex.lab=1,cex=0.5,mgp=c(1.2,0.1,0.1),
             par.corrected=list(col="red", lty=1, lwd=2, pch=4))+
          abline(0, 1, lty=2))
  dev.off()
}


# prepare for the offset model using shrunk coefficients 
# raise it to original scale #
# display final shrunk model #

a<-paste0(paste0(names(data2_12m)[xpos.infectionnew]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)

cox_infectionnew_reduced_scaleback.coxph<-coxph(as.formula(b),data=data_12m,x=T)
cox_infectionnew_reduced_scaleback.cph<-cph(as.formula(b),data=data_12m,
                                         x=T,y=T,surv=T,time.inc=1)
coef_infectionnew_reduced_scaleback<- data.frame(Original = coef(cox_infectionnew_reduced_scaleback.coxph),
                                              Shrunk.BS=c(coef(cox_infectionnew_reduced_scaleback.coxph) * shrinkage.factor))
coef_infectionnew_reduced_scaleback <- tibble::rownames_to_column(coef_infectionnew_reduced_scaleback,"X")

a<-paste0(coef_infectionnew_reduced_scaleback[1,1],"*",
          coef_infectionnew_reduced_scaleback[1,3])
for (i in (2:nrow(coef_infectionnew_reduced_scaleback))){
  a0<-paste0(coef_infectionnew_reduced_scaleback[i,1],"*",
             coef_infectionnew_reduced_scaleback[i,3])
  a<-paste0(c(a,a0),collapse = "+")
}

final_infectionnew<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)
final_infectionnew

# use the final shrunken model for nomogram #
a<-paste0(coef_infectionnew_reduced_scaleback[1,1],"*",
          coef_infectionnew_reduced_scaleback[1,3])
for (i in (2:nrow(coef_infectionnew_reduced_scaleback))){
  a0<-paste0(coef_infectionnew_reduced_scaleback[i,1],"*",
             coef_infectionnew_reduced_scaleback[i,3])
  a<-paste0(c(a,a0),collapse = "+")
}
a<-paste0("offset(",a,")")

b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)
dd <- datadist(data_12m)
options(datadist = 'dd')
model<-cph(as.formula(b),data=data_12m,x=T,y=T,surv=T,time.inc = 1)

cox_infectionnew_final<-cox_infectionnew_reduced_scaleback.cph
cox_infectionnew_final$coefficients<-coef_infectionnew_reduced_scaleback[[3]]
cox_infectionnew_final$sformula<-cox_infectionnew_reduced_scaleback.cph$sformula
cox_infectionnew_final$linear.predictors<-model$linear.predictors
cox_infectionnew_final$surv<-model$surv
cox_infectionnew_final$surv.summary<-model$surv.summary
cox_infectionnew_final$std.err<-model$std.err # standard errors of estimate log-log survival
cox_infectionnew_final$residuals<-model$residuals #martingale residuals
cox_infectionnew_final$loglik[2]<-model$loglik # loglike=initial& final ll
cox_infectionnew_final$center<-mean(model$linear.predictors) # overall mean of Xbeta

# Plot of separation of KM curve across 2/3 groups at centiles of lp #
data_12m$pred_LP <- predict(cox_infectionnew_final,type="lp")
data_12m$centile_LP <- cut(data_12m$pred_LP,breaks=quantile(data_12m$pred_LP,na.rm=T,
                                          seq(0, 1, 0.3)),
                  labels=c(1:3),include.lowest=TRUE)

# Graph the KM curves in the 2/3 risk groups to visually assess separation #
survfit(Surv(time.to.infection/30, Infection_after_RTX==2)~centile_LP,
        data=data_12m)


pdf(file="H:\\AAVprediction\\Analysis\\KM_infectionnew_separationbygroup_shrunk_3grp.pdf")
ggsurvplot(survfit(Surv(time.to.infection/30, Infection_after_RTX==2)~centile_LP,
                   data=data_12m),data=data_12m, risk.table=T,risk.table.col = "centile_LP",
           legend.labs = c("Low risk","Medium risk","High risk"),
           xlab = "Time in months",
           break.x.by=12,conf.int = T,
           surv.median.line = "hv",
           ggtheme = theme_bw() 
)
dev.off()


# Nomograms #
surv.infection<-Survival(cox_infectionnew_final)
nomo_infection<-nomogram(cox_infectionnew_final,
                         fun=list(function(x) surv.infection(1*12,x),
                                  function(x) surv.infection(3*12,x),
                                  function(x) surv.infection(5*12,x)),
                         funlabel=c("1 year survival prob.",
                                    "3 year survival prob.",
                                    "5 year survival prob."),
                         lp=F
)
pdf("H:\\AAVprediction\\Analysis\\nomogram_infectionnew.pdf")
plot(nomo_infection,cex.axis=0.3,xfrac=0.6,cex.var=0.7)
dev.off()

# save data#
save(cox_infectionnew_final,final_infectionnew,file="H:\\AAVprediction\\Analysis\\data_infectionnew.RData")
