# AAV prediction
# 16 Dec 2019 
# Outcome: Time to 1st relapse
# use steroid dose at end RTX, creatine at end RTX

###### LIBRARY ######
#####################
library(devtools)
library(caret)
library(prodlim)
library(muhaz)
library(survival)
library(survminer)
library(Hmisc)
library(rms)
library(reshape2)
library(mfp)
library(rstpm2)
library(flexsurv)
library(dplyr)
library(qwraps2)
library(survminer)
library(ggfortify)
library(lsr)
library(ggcorrplot)
library(skimr)
library(purrr)
library(tidyr)
library(nonnestcox)
library(DynNom)
library(lubridate)
library(survminer)


######################

################################
# Data preparation for RELASPE #
################################

setwd("H:\\AAVprediction\\Analysis")
data <- read.csv("H:\\AAVprediction\\AAV data\\relapse_infection_data_final.csv",
                 header=TRUE)
dim(data)
summary(data)

# compute time-to-relapse in days #
data$time.to.relapse<-pmin(as.numeric(difftime(as.Date(as.character(data$Date_of_last_follow_up),format="%d/%m/%Y"),
                               as.Date(as.character(data$Date_last_RTX),format="%d/%m/%Y"),
                               units="days")), 
                           as.numeric(difftime(as.Date(as.character(data$Date_of_relapse),format="%d/%m/%Y"),
                                               as.Date(as.character(data$Date_last_RTX),format="%d/%m/%Y"),
                                               units="days")),na.rm=T)
#double check: passed #
a<-pmin(as.numeric(difftime(dmy(data$Date_of_last_follow_up),
                            dmy(data$Date_last_RTX),
                            units="days")), 
        as.numeric(difftime(dmy(data$Date_of_relapse),
                            dmy(data$Date_last_RTX),
                            units="days")),na.rm=T)

# remove individuals where last follow-up date <= last RTX date #
data<-data[!(data$time.to.relapse<0.00001),] # left with 147 IDs

# create difference in Creatinine_start and end are highly correlated #
data<-data %>%
  mutate(Concomitant_CYC_oralIS=case_when(Concomitant_CYC==1|Concomitant_oral_IS==1~"1plus",
                                          TRUE~ "0"))
# change ANCA-subtype label to be meaningful #
data$ANCA_subtype<-factor(data$ANCA_subtype,
                          levels=c("0","1","2"),
                          labels=c("Negative","MPO","PR3"))
data$Sex<-factor(data$Sex,
                 levels=c("0","1"),
                 labels=c("Female","Male"))
# group indication for RTX into two (non-relapse) & relapse #
data$Indication_for_RTX<-factor(data$Indication_for_RTX, 
                                levels=c("0", "1","2"), 
                                labels=c("No_relapse","Relapse","No_relapse"))

# make age categorical as a stratification factor #
data$Age_strata<- cut(data$Age, 
                      breaks=c(-Inf, 60, Inf), 
                      labels=c("60minus","60plus"))


# shorten covariate names for easy display #
names(data)[c(14,18,21)]<-c("Cumulative_CYC_before_1st_RTX",
                            "Cumulative_steroid_dose",
                            "ANCA_positive_at_end_RTX")


# identify categorical predictors & age variables #
data[,c("Sex","Indication_for_RTX","Clinical_subtype",
        "ANCA_subtype","ENT_involvement","Concomitant_CYC",
        "Concomitant_oral_IS","Prev_RTX_ever","Off_steroids_at_end_RTX",
        "ANCA_positive_at_end_RTX","Future_IVIG",
        "On_antibiotic_prophylaxis_at_end_RTX","Number_of_serious_infections_during_RTX",
        "Serious_infection_after_RTX","Relapse_after_RTX","Concomitant_CYC_oralIS",
        "Age_strata")] <- lapply(data[,c("Sex","Indication_for_RTX","Clinical_subtype",
                                         "ANCA_subtype","ENT_involvement","Concomitant_CYC",
                                         "Concomitant_oral_IS","Prev_RTX_ever","Off_steroids_at_end_RTX",
                                         "ANCA_positive_at_end_RTX","Future_IVIG",
                                         "On_antibiotic_prophylaxis_at_end_RTX",
                                         "Number_of_serious_infections_during_RTX",
                                         "Serious_infection_after_RTX",
                                         "Relapse_after_RTX","Concomitant_CYC_oralIS","Age_strata")],factor)  

# generate number of infections during RTX: infection is defined as 1 serious or 3 non-serious #
data$num_nonseriousinfection_during_RTX<-as.factor(case_when(as.numeric(data$Number_of_non_serious_infections_during_RTX)-1>2|
                                                     as.numeric(data$Number_of_serious_infections_during_RTX)-1>1 ~ "Infection",
                                                   TRUE ~ "Others"))

indices_rel<-match(c("Relapse_after_RTX","time.to.relapse","Sex","Indication_for_RTX",
                     "ANCA_subtype","ENT_involvement","Structural_lung_disease","Concomitant_CYC_oralIS",
                     "ANCA_positive_at_end_RTX",
                     "Steroid_dose_at_end_RTX",
                     "Creatinine_at_end_RTX","Cumulative_CYC_before_1st_RTX","Age_strata",
                     "Age","Cumulative_RTX_g"),names(data))
names(data[indices_rel])



#View(data[,c("Number_of_serious_infections_during_RTX","Number_of_non_serious_infections_during_RTX","num_nonseriousinfection_during_RTX")])


# Prepare summary statistics for table #
summarydata<-data[indices_rel] %>% group_by(Relapse_after_RTX) %>% skim() 
capture.output(print(summarydata),file="H:\\AAVprediction\\Analysis\\summary_relapse.txt")

summary1 <-
  # categorical #
  list(
  "Gender" =
    list("Female" = ~ qwraps2::n_perc0(.data$Sex=="Female"),
         "Male" = ~ qwraps2::n_perc0(.data$Sex =="Male")),
  "Age_strata" =
    list("60minus" = ~ qwraps2::n_perc0(.data$Age_strata == "60minus"),
         "60plus" = ~ qwraps2::n_perc0(.data$Age_strata == "60plus")),
    "ANCA positive at end RTX" =
    list("No" = ~ qwraps2::n_perc0(.data$ANCA_positive_at_end_RTX == 0),
         "Yes" = ~ qwraps2::n_perc0(.data$ANCA_positive_at_end_RTX == 1)),
  "ANCA subtype" =
    list("Negative" = ~ qwraps2::n_perc0(.data$ANCA_subtype == "Negative"),
         "MPO" = ~ qwraps2::n_perc0(.data$ANCA_subtype =="MPO"),
         "PR3" = ~ qwraps2::n_perc0(.data$ANCA_subtype =="PR3")),
  "Concomitant CYC or oral IS" =
    list("None" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "0"),
         "1+" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "1plus")),
  "ENT invovlement" =
    list("No" = ~ qwraps2::n_perc0(.data$ENT_involvement == 0),
         "Yes" = ~ qwraps2::n_perc0(.data$ENT_involvement == 1)),
  "Structural lung disease" =
    list("No" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 0),
         "Yes" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 1)),
  "Number of infections during RTX" =
    list("1+ serious or 3+ non-serious infections" = ~ qwraps2::n_perc0(.data$num_nonseriousinfection_during_RTX == "Infection"),
         "Others" = ~ qwraps2::n_perc0(.data$num_nonseriousinfection_during_RTX == "Others")),
  "Indication for RTX" =
    list("No relapse" = ~ qwraps2::n_perc0(.data$Indication_for_RTX == "No_relapse"),
         "Relapse" = ~ qwraps2::n_perc0(.data$Indication_for_RTX == "Relapse")),
  "Age" =
    list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Age,na_rm = T)),
  "Creatinine at end RTX" =
    list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Creatinine_at_end_RTX,na_rm = T)),
  "Cumulative RTX g" =
    list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_RTX_g,na_rm = T)),
  "Cumulative CYC prior to 1st RTX" =
    list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_CYC_before_1st_RTX,na_rm = T)),
  "Steroid dose at end RTX" =
    list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Steroid_dose_at_end_RTX ,na_rm = T))
  )

summary_table1 <- summary_table(dplyr::group_by(data, Relapse_after_RTX), summary1)
summary_table2 <- summary_table(data,summary1)
summary_tablex<-cbind(summary_table2,summary_table1)
capture.output(print(summary_tablex),file="H:\\AAVprediction\\Analysis\\summary_relapse.txt")

# Overlapped histograms for all numeric preditors #
data$Relapse_after_RTX<-factor(data$Relapse_after_RTX,
                                  levels=c("0","1"),
                                  labels=c("No","Yes"))

names(data[indices_rel])

pdf(file="H:\\AAVprediction\\Analysis\\dist_relapse_contvars.pdf")
# 5= 5 continuous variables (inc. age) for relapse #
data[indices_rel[-c(1:2)]] %>%
  keep(is.numeric) %>% 
  gather() %>% 
  ggplot(aes(value,fill=rep(data$Relapse_after_RTX, 5))) +
  facet_wrap(~ key, scales = "free",ncol = 2) +
  geom_histogram(alpha=0.5, position="identity")+
  labs(fill = "Relapse after RTX") +
  theme(text = element_text(size=8))
dev.off()

#create dummies for all categorical predictors#
data<-fastDummies::dummy_cols(data,c("Sex","Age_strata","ANCA_positive_at_end_RTX",
                                     "ANCA_subtype","Concomitant_CYC_oralIS",
                                     "ENT_involvement","Structural_lung_disease",
                                     "num_nonseriousinfection_during_RTX",
                                     "Indication_for_RTX"))
data$Relapse_after_RTX<-as.numeric(data$Relapse_after_RTX) # 1=no event, 2= event

#  describe time-to-1st relapse #
km_relapse <- survfit(Surv(time.to.relapse/30, Relapse_after_RTX==2) ~ 1, data=data)
summary(km_relapse)
pdf(file="H:\\AAVprediction\\Analysis\\KM_relapse.pdf")
ggsurvplot(km_relapse, data = data,xlab="Time (Months)",palette="Black",risk.table=T)
dev.off()


################
# COX PH model #
################

# add predictors: age strata (to replace raw age, indicator for infection have happened or not before relapse
data$Serious_infection_after_RTX<-as.factor(data$Serious_infection_after_RTX)
data$Relapse_after_RTX<-as.numeric(data$Relapse_after_RTX)
table(data$Relapse_after_RTX) #2=event

# Normalise all continuous predictors (6 for relapse) #
data2<-data %>% mutate_each_(list(~scale(.,center=T,scale=T) %>% as.vector),
                             vars=c("Creatinine_at_end_RTX","Cumulative_RTX_g",
                                    "Cumulative_CYC_before_1st_RTX","Steroid_dose_at_end_RTX",
                                    "Age"))

# log-transform all continuous predictors (6 for relapse) #
data3<-data %>% mutate_each_(list(~log(.+0.5) %>% as.vector),
                             vars=c("Creatinine_at_end_RTX","Cumulative_RTX_g",
                                    "Cumulative_CYC_before_1st_RTX","Steroid_dose_at_end_RTX",
                                    "Age"))


# the largest category is taken as reference (for 3-category variable) #
xpos.relapse<-match(c("Sex_Male","Age_strata_60plus","ANCA_positive_at_end_RTX_1",
                      "ANCA_subtype_Negative","ANCA_subtype_MPO",
                      "Concomitant_CYC_oralIS_1plus","ENT_involvement_1",
                      "Structural_lung_disease_1",
                      "Indication_for_RTX_Relapse",
                      "Creatinine_at_end_RTX","Cumulative_RTX_g",
                      "Cumulative_CYC_before_1st_RTX","Steroid_dose_at_end_RTX"),
                    names(data))
names(data)[xpos.relapse]

a<-paste0(paste0(names(data)[xpos.relapse]), collapse= "+")
b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)

# compare log-transformed vs normalised model: which is better? log-transformed#
relapse1<-coxph(as.formula(b), data = data2,x=T) # normalised
relapse2<-coxph(as.formula(b), data = data3,x=T) # log-transformed
  
  # non-nested LRT for distinguiableness#
  plrtest(relapse1,relapse2,nested=F) # p=0.907, non-distinguishable
  
  # compared c-index #
  relapse1$concordance[6]/relapse2$concordance[6] # normalised wins!

  # plot results side-by-side #
  pdf(file="H:\\AAVprediction\\Analysis\\cox_relapse_normalised.pdf")
  ggforest(relapse1, data= data2,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
  dev.off()
  
  pdf(file="H:\\AAVprediction\\Analysis\\cox_relapse_logtransformed.pdf")
  ggforest(relapse2, data= data3,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
  dev.off()

# global test of the ANCA-subtype variable #
c<-paste0(paste0(names(data)[xpos.relapse[-c(4:5)]]), collapse= "+")
c<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",c)
a1<-relapse1
a2<-coxph(as.formula(c), data = data2,x=T)
plrtest(a1,a2,nested=T) # p=0.7

# Check correlation among normalised predictors: all seems fine #
lapply(data2[xpos.relapse],class)
corr.x<-cor(data[xpos.relapse],use="complete.obs")
pdf(file="H:\\AAVprediction\\Analysis\\corr_relapseX.pdf")
ggcorrplot(corr.x, hc.order = TRUE, type = "lower",
           outline.col = "white", tl.cex = 6,lab=T,lab_size=2)
dev.off()

##############################################################################

# Use internal calibration to select the reduced model #
# save data for new predition use#
setwd("H:\\AAVprediction\\Analysis")
save(data,data2,file="H:\\AAVprediction\\Analysis\\data_relapse.RData")


# rerun full model #
xpos.relapse<-match(c("Sex_Male","Age_strata_60plus","ANCA_positive_at_end_RTX_1",
                      "ANCA_subtype_Negative","ANCA_subtype_MPO",
                      "Concomitant_CYC_oralIS_1plus","ENT_involvement_1",
                      "Structural_lung_disease_1",
                      "Indication_for_RTX_Relapse",
                      "Creatinine_at_end_RTX","Cumulative_RTX_g",
                      "Cumulative_CYC_before_1st_RTX","Steroid_dose_at_end_RTX"),
                    names(data2))

names(data2)[xpos.relapse]
a<-paste0(paste0(names(data2)[xpos.relapse[-c(4:5)]]), collapse= "+")
a<-paste0(a,"+ANCA_subtype") # need to treat ANCA_subtype as a whole!
b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)
cox_relapse.cph<- cph(as.formula(b), data = data2,x=T,y=T,surv=T)
cox_relapse.coxph<-coxph(as.formula(b), data = data2,x=T)

# Shrinkage & optimism adjusted AUC, CITL etc. using bootstrapping
# with backward variable selection method:p-values >=p/10 would be dropped #
boot_results<-matrix(nrow=10,ncol=2)
pos<-1
for (p in c(3,4,5,6,6.5,7,7.5,8,8.5,9)) {
  print(p)
  set.seed(12345) # to ensure reproducibility
  boot_relapse<-validate(cox_relapse.cph,method="boot",B=1000,
                           bw=T,rule="p",type="individual",
                           sls=p/10)
  boot_relapse<-rbind(c((boot_relapse[1,1:3]+1)/2,
                          (boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2,
                          (boot_relapse[1,1]+1)/2-((boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2),
                          boot_relapse[1,6]),
                        boot_relapse)
  rownames(boot_relapse)[1]<-"c-index"
  colnames(boot_relapse)<-c("Apparent","BS_training","BS_test","Optimism",
                              "Optimism-corrected","rep")
  boot_results[pos,1]<-boot_relapse[4,5] # index-corrected slope
  boot_results[pos,2]<-boot_relapse[1,5] # index-corrected c-index
  pos<-pos+1
}
boot_results
capture.output(boot_results,
               file="H:\\AAVprediction\\Analysis\\relapse_boot_results.txt")

  
  p<-0.65
  set.seed(12345) # to ensure reproducibility
  boot_relapse<-validate(cox_relapse.cph,method="boot",B=1000,
                         bw=T,rule="p",type="individual",
                         sls=p)
  boot_relapse[1:7,1:6]
  
  # Convert Dxy to c-index
  boot_relapse<-rbind(c((boot_relapse[1,1:3]+1)/2,
                        (boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2,
                        (boot_relapse[1,1]+1)/2-((boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2),
                        boot_relapse[1,6]),
                      boot_relapse)
  rownames(boot_relapse)[1]<-"c-index"
  colnames(boot_relapse)<-c("Apparent","BS_training","BS_test","Optimism",
                            "Optimism-corrected","rep")
  boot_relapse
  capture.output(boot_relapse,file="H:\\AAVprediction\\Analysis\\relapse_reduced_internal.txt")
  
  # retrieved 7 factors in the final model #
  xpos.relapse<-match(c("Sex_Male","Age_strata_60plus","ANCA_positive_at_end_RTX_1",
                        "Concomitant_CYC_oralIS_1plus","ENT_involvement_1",
                        "Indication_for_RTX_Relapse",
                        "Steroid_dose_at_end_RTX"),
                      names(data2))
  names(data2)[xpos.relapse]
  
  a<-paste0(paste0(names(data2)[xpos.relapse]), collapse= "+")
  b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)
  
  cox_relapse_reduced.coxph<-coxph(as.formula(b), data = data2,x=T)
  cox_relapse_reduced.cph<- cph(as.formula(b), data = data2,x=T,y=T,surv=T,time.inc=1)
  
  
  # PLOT TWO MODELS: full model & reduced model with readable labels #
  pdf(file="H:\\AAVprediction\\Analysis\\cox_relapse.pdf")
  ggforest(relapse1, data= data2,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
  dev.off()
  
  pdf(file="H:\\AAVprediction\\Analysis\\cox_relapse_reduced.pdf")
  ggforest(cox_relapse_reduced.coxph, data = data2,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
  dev.off()
  
  # Test for PH assumption - residual distribution #
  cox.zph(cox_relapse_reduced.coxph)
  pdf(file="H:\\AAVprediction\\Analysis\\cox_relapse_reduced_PHtest.pdf")
  ggcoxzph(cox.zph(cox_relapse_reduced.coxph),font.main=5,font.x=6,font.y=5,
           font.xtickslab=6,font.ytickslab=6)
  dev.off()

  
  # Shrinkage coefficients to improve prediction #
  shrinkage.factor<-boot_relapse["Slope","Optimism-corrected"]
  coef_relapse_reduced<- data.frame(Original = coef(cox_relapse_reduced.coxph),
                                    Shrunk.BS=c(coef(cox_relapse_reduced.coxph) * boot_relapse["Slope","Optimism-corrected"]))
  capture.output(round(coef_relapse_reduced, 3),file="H:\\AAVprediction\\Analysis\\relapse_reduced_internal_shrunken.txt")
  
  # PI & C-index for reduced vs shrunk model#
  pred_LP <- predict(cox_relapse_reduced.coxph,type="lp",reference="sample")
  summary(cox_relapse_reduced.coxph)$concordance[1]
  summary(cox_relapse_reduced.coxph)$concordance[1]-(1.96*summary(cox_relapse_reduced.coxph)$concordance[2])
  summary(cox_relapse_reduced.coxph)$concordance[1]+(1.96*summary(cox_relapse_reduced.coxph)$concordance[2])
  # so apparent c-index= 0.616 [95%CI 0.545, 0.687]
  
  
  ###########################################################
  
  # calibrate the shrunken model (BS) using bootstrap samples #
  # how well is the model at discrimination #
  coef_relapse_reduced <- tibble::rownames_to_column(coef_relapse_reduced,"X")
  coef_relapse_reduced
  
  # Final model #
  # calibrate the final model (horizon=1-6 years,
  # present both uncalibrate & calibrated models) #
  horizon<-12*seq(1,6,1)

  for (i in 1:length(horizon)){
    tempmodel<- cph(cox_relapse_reduced.cph$sformula, data = data2,
                            x=T,y=T,surv=T,
                            time.inc=horizon[i])

    set.seed(12345) # to ensure reproducibility
    #cal<-calibrate(tempmodel,u=horizon[i],B=1000,maxdim=10) # to add on smoothness
    cali_relapse<-calibrate(tempmodel,u=horizon[i],m=146/4,
                            cmethod="KM",method="boot",B=1000)
    fpath<-paste0("H:\\AAVprediction\\Analysis\\calib_relapse",horizon[i]/12, 
                  " yr.pdf")
    pdf(file=fpath)
    print(plot(cali_relapse,subtitles=F,ylab=paste0("Observed survival (KM)",horizon[i]/12, " years"),   
                 xlab=paste0("Predicted survival",horizon[i]/12, " years"),
                 xlim=c(0,1),ylim=c(0,1),
                cex.lab=1,cex=0.5,mgp=c(1.2,0.1,0.1),
                par.corrected=list(col="red", lty=1, lwd=2, pch=4))+
            abline(0, 1, lty=2))
    dev.off()
  }
  
  # prepare for the offset model using shrunk coefficients 
  # raise it to original scale #
  # display final shrunk model #
  cox_relapse_reduced_scaleback.coxph<-coxph(as.formula(b),data=data,x=T)
  cox_relapse_reduced_scaleback.cph<-cph(as.formula(b),data=data,
                                           x=T,y=T,surv=T,time.inc=T)
  coef_relapse_reduced_scaleback<- data.frame(Original = coef(cox_relapse_reduced_scaleback.coxph),
                                    Shrunk.BS=c(coef(cox_relapse_reduced_scaleback.coxph) * shrinkage.factor))
  coef_relapse_reduced_scaleback <- tibble::rownames_to_column(coef_relapse_reduced_scaleback,"X")
  
  a<-paste0(coef_relapse_reduced_scaleback[1,1],"*",
            coef_relapse_reduced_scaleback[1,3])
  for (i in (2:nrow(coef_relapse_reduced_scaleback))){
    a0<-paste0(coef_relapse_reduced_scaleback[i,1],"*",
               coef_relapse_reduced_scaleback[i,3])
    a<-paste0(c(a,a0),collapse = "+")
  }
  
  final_relapse<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)
  final_relapse
  
  # use the final shrunken model for nomogram #
  a<-paste0(coef_relapse_reduced_scaleback[1,1],"*",
            coef_relapse_reduced_scaleback[1,3])
  for (i in (2:nrow(coef_relapse_reduced_scaleback))){
    a0<-paste0(coef_relapse_reduced_scaleback[i,1],"*",
               coef_relapse_reduced_scaleback[i,3])
    a<-paste0(c(a,a0),collapse = "+")
  }
  a<-paste0("offset(",a,")")
  
  b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)
  dd <- datadist(data)
  options(datadist = 'dd')
  model<-cph(as.formula(b),data=data,x=T,y=T,surv=T,time.inc = 1)
  
  cox_relapse_final<-cox_relapse_reduced_scaleback.cph
  cox_relapse_final$coefficients<-coef_relapse_reduced_scaleback[[3]]
  cox_relapse_final$sformula<-cox_relapse_reduced_scaleback.cph$sformula
  cox_relapse_final$linear.predictors<-model$linear.predictors
  cox_relapse_final$surv<-model$surv
  cox_relapse_final$surv.summary<-model$surv.summary
  cox_relapse_final$std.err<-model$std.err # standard errors of estimate log-log survival
  cox_relapse_final$residuals<-model$residuals #martingale residuals
  cox_relapse_final$loglik[2]<-model$loglik # loglike=initial& final ll
  cox_relapse_final$center<-mean(model$linear.predictors) # overall mean of Xbeta

    # Plot of separation of KM curve across 2/3 groups at centiles of lp #
    data$pred_LP <- predict(cox_relapse_final,type="lp")
    data$centile_LP <- cut(data$pred_LP,breaks=quantile(data$pred_LP,na.rm=T,
                                              seq(0, 1, 0.5)),
                      labels=c(1:2),include.lowest=TRUE)
    
    # Graph the KM curves in the 2/3 risk groups to visually assess separation #
    survfit(Surv(time.to.relapse/30, Relapse_after_RTX==2)~centile_LP,data=data) # get median survival time
    
    pdf(file="H:\\AAVprediction\\Analysis\\KM_relapse_separationbygroup_shrunk_2grp.pdf")
   ggsurvplot(survfit(Surv(time.to.relapse/30, Relapse_after_RTX==2)~centile_LP,
                 data=data),data=data, risk.table=T,risk.table.col = "centile_LP",
              legend.labs = c("Low risk", "High risk"),
              xlab = "Time in months",
              break.x.by=12,
              surv.median.line = "hv",
              ggtheme = theme_bw() 
   )
   
    dev.off()

save(data,data2,cox_relapse_final,final_relapse,file="H:\\AAVprediction\\Analysis\\data_relapse.RData")    

# Nomograms #
    surv.relapse<-Survival(cox_relapse_final)
    nomo_relapse<-nomogram(cox_relapse_final,
                           fun=list(function(x) surv.relapse(1*12,x),
                                    function(x) surv.relapse(3*12,x),
                                    function(x) surv.relapse(5*12,x)),
                           funlabel=c("1 year survival prob.",
                                      "3 year survival prob.",
                                      "5 year survival prob."),
                           lp=F
                           )
    pdf("H:\\AAVprediction\\Analysis\\nomogram_relapse.pdf")
    plot(nomo_relapse,cex.axis=0.3,xfrac=0.6,cex.var=0.7)
    dev.off()


####################################################################
# legacy codes #
# # prepare for PH model by first checking if population curves are similar across predictor groups #
# 
# for (i in 1:length(simple.xpos)) {
#   # for all continuous predictors, normalise it #
#   if (class(data[[simple.xpos[i]]])!="factor") {
#     data[[simple.xpos[i]]]<-as.numeric(scale(data[[simple.xpos[i]]],
#                                              center=T,scale=T))
#   }
#   
#   # for all factor predictors - plot surv & log-rank test results #
#   # log-rank tests if two survival functions are identifical (H0) # 
#   if (class(data[[simple.xpos[i]]])=="factor") {
#     print(names(data[simple.xpos[i]]))
#     fpath<-paste0("H:\\AAVprediction\\Analysis\\KM_",names(data[simple.xpos[i]]),".pdf")
#     pdf(file=fpath)
#     a<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==1)","~",names(data[simple.xpos[i]]))
#     print(
#       ggsurvplot(
#         survfit(as.formula(a),data=data), # survfit object with calculated statistics.
#         data = data,             # data used to fit survival curves.
#         risk.table = TRUE,       # show risk table.
#         pval = TRUE,             # show p-value of log-rank test.
#         conf.int = TRUE,         # show confidence intervals for 
#         xlab = "Time (Months)",   # customize X axis label.
#         ggtheme = theme_light(), # customize plot and risk table with a theme.
#         risk.table.y.text.col = F, # colour risk table text annotations.
#         risk.table.y.text = T,
#         linetype = "strata",
#         palette = "grey")
#     )
#     dev.off()
#   }
# }


# # Test for PH assumption - -log(-log(S(t)) vs log(t) should be parallel by group #
# for (i in 1:length(xpos.relapse2)) {
#   
#   # for all factor predictors - plot parallel curve
#   if (class(data[[xpos.relapse2[i]]])=="factor") {
#     print(names(data[xpos.relapse2[i]]))
#     fpath<-paste0("H:\\AAVprediction\\Analysis\\relapse_cloglog_",names(data[xpos.relapse2[i]]),".pdf")
#     pdf(file=fpath)
#     a<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX)","~",names(data[xpos.relapse2[i]]))
#     graphs<- ggsurvplot(survfit(as.formula(a),data=data),
#                         data=data,palette = "grey",
#                         fun = function(s) -log(-log(s)), 
#                         xlab = "Time (months)", 
#                         ylab = "-log(- log(Survival))", 
#                         main=names(data[xpos.relapse2[i]]), 
#                         linetype = "strata")
#     print(graphs)
#     dev.off()
#   }
# }
# 
# # Note, when two test give different results, schoenfeld residuals are more trustworthy #

