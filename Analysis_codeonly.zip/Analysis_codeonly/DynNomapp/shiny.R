# updated: 25 Sept 2019 #

###### LIBRARY ######
#####################
library(devtools)
library(caret)
library(prodlim)
library(muhaz)
library(survival)
library(survminer)
library(Hmisc)
library(rms)
library(reshape2)
library(mfp)
library(rstpm2)
library(flexsurv)
library(dplyr)
library(qwraps2)
library(survminer)
library(ggfortify)
library(lsr)
library(ggcorrplot)
library(skimr)
library(purrr)
library(tidyr)
library(nonnestcox)
library(DynNom)
library(shiny)
library(MASS)

######################

# load relevant data #
load(file="H:\\AAVprediction\\Analysis\\data_relapse.RData")
load(file="H:\\AAVprediction\\Analysis\\data_relapsenew.RData")
load(file="H:\\AAVprediction\\Analysis\\data_infection.RData")
load(file="H:\\AAVprediction\\Analysis\\data_infectionnew.RData")

#colnames(cox_relapsenew_final$var)

ui <- navbarPage("AAV relapse/infection risk calculator",header = "Disclaimer: all models have not been externally validated, please use with caution.",
                 ###########
                 # RELAPSE #
                 ###########
                 
                 tabPanel("Relapse",
                    # Input
                    sidebarLayout(
                       sidebarPanel(
                          numericInput("Sex_Male_1","Gender (Male=1,Female=0)",value=0),
                          numericInput("ANCA_positive_at_end_RTX_1_1","ANCA positive at end RTX (Yes=1,No=0)",value=0),
                          numericInput("Concomitant_CYC_oralIS_1plus_1","Concomitant CYC/oral IS (At least one=1,None=0)",value=0),
                          numericInput("ENT_involvement_1_1","ENT invovlement (Yes=1,No=0)",value=0),
                          numericInput("Indication_for_RTX_Relapse_1","Indication for RTX Relapse (Yes=1,No=0)",value=0),
                          numericInput("Creatinine_at_start_RTX_1","Creatinine at start RTX (unit)",value=0),
                          numericInput("Cumulative_CYC_before_1st_RTX_1","Cumulative CYC before 1st RTX (unit)",value=0),
                          numericInput("Cumulative_steroid_dose_1","Cumulative steroid dose (g)",value=0)),
                    # Output  
                    mainPanel(
                       textOutput("text11"),
                       textOutput("text13"),
                       textOutput("text15"))
                 )),
                 
                 ###################
                 # RELAPSE_updated #
                 ###################
                 
                 tabPanel("Relapse_update after 1 year",
                 # Input
                 sidebarLayout(
                    sidebarPanel(
                       numericInput("ENT_involvement_1_2","ENT invovlement (Yes=1,No=0)",value=0),
                       numericInput("Indication_for_RTX_Relapse_2","Indication for RTX Relapse (Yes=1,No=0)",value=0),
                       numericInput("ANCA_positive_at_12m_1_2", "ANCA positive at 12th month (Yes=1,No=0)",value=0),
                       numericInput("Creatinine_at_start_RTX_2","Creatinine at start RTX (unit)",value=0),
                       numericInput("Cumulative_CYC_before_1st_RTX_2","Cumulative CYC before 1st RTX (unit)",value=0),
                       numericInput("Cumulative_steroid_dose_2","Cumulative steroid dose (g)",value=0)),
                    # Output  
                    mainPanel(
                       textOutput("text21"),
                       textOutput("text23"),
                       textOutput("text25"))
                 )),

                  #############
                  # INFECTION #
                  #############

                  tabPanel("Infection",
                  # Input
                  sidebarLayout(
                     sidebarPanel(
                        numericInput("Sex_Male_3","Gender (Male=1,Female=0)",value=0),
                        numericInput("Age_strata_70plus_3","Age (70+=1,<70=0)",value=0),
                        numericInput("Structural_lung_disease_1_3","Structural lung disease (Yes=1,No=0)",value=0),
                        numericInput("Diabetes_1_3","Diabetes (Yes=1,No=0)",value=0),
                        numericInput("On_antibiotic_prophylaxis_at_end_RTX_1_3",
                                     "On antibiotic prophylaxis at end RTX 1 (Yes=1,No=0)",value=0),
                        numericInput("Cumulative_steroid_dose_3","Cumulative steroid dose (g)",value=0),
                        numericInput("Creatinine_at_start_RTX_3","Creatinine at start RTX (unit)",value=0),
                        numericInput("IgG_at_end_RTX_3","IgG at end RTX (unit)",value=0)),
                     # Output  
                     mainPanel(
                        textOutput("text31"),
                        textOutput("text33"),
                        textOutput("text35"))
                  )),
                 
                 #####################
                 # INFECTION_updated #
                 #####################
                 
                 tabPanel("Infection_updated after 1 year",
                          # Input
                          sidebarLayout(
                             sidebarPanel(
                                numericInput("Structural_lung_disease_1_4","Structural lung disease (Yes=1,No=0)",value=0),
                                numericInput("Diabetes_1_4","Diabetes (Yes=1,No=0)",value=0),
                                numericInput("Lymphocyte_count_at_12mcat_1minus_4",
                                             "Lymphocyte count at 12th month <1 (Yes=1,No=0)",value=0),
                                numericInput("IgG_at_12m_4","IgG at 12 months (unit)",value=0),
                                numericInput("Creatinine_at_start_RTX_4","Creatinine at start RTX (unit)",value=0)),
                             # Output  
                             mainPanel(
                                textOutput("text41"),
                                textOutput("text43"),
                                textOutput("text45"))
                          ))
)

# Haven't updated server! 
server<-function(input, output){
   ###########
   # RELAPSE #
   ############
   
   
   # Text string to display survival outcomes
      # Execute the "inputdata" function to save the dataframe as "data"
   output$text11 <- renderText({
      # linear predictor
      lp=input$Sex_Male_1*0.200262283730943+
         input$ANCA_positive_at_end_RTX_1_1*0.113210447776126+
         input$Concomitant_CYC_oralIS_1plus_1*-0.108483508182961+
         input$ENT_involvement_1_1*0.473162143244739+
         input$Indication_for_RTX_Relapse_1*0.0620166856532124+
         input$Creatinine_at_start_RTX_1*-0.000808939900710973+
         input$Cumulative_CYC_before_1st_RTX_1*0.00166695476836393+
         input$Cumulative_steroid_dose_1*-5.01333619702693e-05
      
      # Determine the survival probability for 1,3,5 years 
      surv.relapse=Survival(cox_relapse_final)
      paste0("1-year survival probability: ",round(surv.relapse(1*12,lp),3))
   })
   
   output$text13 <- renderText({
      lp=input$Sex_Male_1*0.200262283730943+
         input$ANCA_positive_at_end_RTX_1_1*0.113210447776126+
         input$Concomitant_CYC_oralIS_1plus_1*-0.108483508182961+
         input$ENT_involvement_1_1*0.473162143244739+
         input$Indication_for_RTX_Relapse_1*0.0620166856532124+
         input$Creatinine_at_start_RTX_1*-0.000808939900710973+
         input$Cumulative_CYC_before_1st_RTX_1*0.00166695476836393+
         input$Cumulative_steroid_dose_1*-5.01333619702693e-05
      
      # Determine the survival probability for 1,3,5 years 
      surv.relapse=Survival(cox_relapse_final)
      paste0("3-year survival probability:", round(surv.relapse(3*12,lp),3))
   })
   
   output$text15 <- renderText({
      lp=input$Sex_Male_1*0.200262283730943+
         input$ANCA_positive_at_end_RTX_1_1*0.113210447776126+
         input$Concomitant_CYC_oralIS_1plus_1*-0.108483508182961+
         input$ENT_involvement_1_1*0.473162143244739+
         input$Indication_for_RTX_Relapse_1*0.0620166856532124+
         input$Creatinine_at_start_RTX_1*-0.000808939900710973+
         input$Cumulative_CYC_before_1st_RTX_1*0.00166695476836393+
         input$Cumulative_steroid_dose_1*-5.01333619702693e-05
      
      # Determine the survival probability for 1,3,5 years 
      surv.relapse=Survival(cox_relapse_final)
      paste0("5-year survival probability: ",round(surv.relapse(5*12,lp),3))
   })

   ##################
   # RELAPSE_update #
   ##################
  
      
      # Text string to display survival outcomes
      # Execute the "inputdata" function to save the dataframe as "data"
      output$text21 <- renderText({
         # linear predictor
         lp=input$ENT_involvement_1_2*0.48711351878822+
            input$Indication_for_RTX_Relapse_2*0.326543352168598+
            input$ANCA_positive_at_12m_1_2*0.622875901515435+
            input$Creatinine_at_start_RTX_2*-0.0016960598543145+
            input$Cumulative_CYC_before_1st_RTX_2*0.00448177606583448+
            input$Cumulative_steroid_dose_2*-2.89521787883962e-05
         
         
         # Determine the survival probability for 1,3,5 years 
         surv.relapsenew=Survival(cox_relapsenew_final)
         paste0("1-year survival probability: ",round(surv.relapsenew(1*12,lp),3))
      })
      
      output$text23 <- renderText({
         # linear predictor
         lp=input$ENT_involvement_1_2*0.48711351878822+
            input$Indication_for_RTX_Relapse_2*0.326543352168598+
            input$ANCA_positive_at_12m_1_2*0.622875901515435+
            input$Creatinine_at_start_RTX_2*-0.0016960598543145+
            input$Cumulative_CYC_before_1st_RTX_2*0.00448177606583448+
            input$Cumulative_steroid_dose_2*-2.89521787883962e-05
         
         
         # Determine the survival probability for 1,3,5 years 
         surv.relapsenew=Survival(cox_relapsenew_final)
         paste0("3-year survival probability:", round(surv.relapsenew(3*12,lp),3))
      })
      
      output$text25 <- renderText({
         # linear predictor
         lp=input$ENT_involvement_1_2*0.48711351878822+
            input$Indication_for_RTX_Relapse_2*0.326543352168598+
            input$ANCA_positive_at_12m_1_2*0.622875901515435+
            input$Creatinine_at_start_RTX_2*-0.0016960598543145+
            input$Cumulative_CYC_before_1st_RTX_2*0.00448177606583448+
            input$Cumulative_steroid_dose_2*-2.89521787883962e-05
         
         
         # Determine the survival probability for 1,3,5 years 
         surv.relapsenew=Survival(cox_relapsenew_final)
         paste0("5-year survival probability: ",round(surv.relapsenew(5*12,lp),3))
      })

   
   ###########
   # INFECTION #
   ############
   
      
      # Text string to display survival outcomes
      # Execute the "inputdata" function to save the dataframe as "data"
      output$text31 <- renderText({
         # linear predictor
         lp=input$Sex_Male_3*-0.112355374515625+
            input$Age_strata_70plus_3*-0.116376739756864+
            input$Structural_lung_disease_1_3*0.499509955236382+
            input$Diabetes_1_3*0.817031753398502+
            input$On_antibiotic_prophylaxis_at_end_RTX_1_3*-0.160681398815763+
            input$Cumulative_steroid_dose_3*-6.90240300279983e-05+
            input$Creatinine_at_start_RTX_3*-0.00152252874523432+
            input$IgG_at_end_RTX_3*-0.13176898846253
         
         # Determine the survival probability for 1,3,5 years 
         surv.infection=Survival(cox_infection_final)
         paste0("1-year survival probability: ",round(surv.infection(1*12,lp),3))
      })
      
      output$text33 <- renderText({
         # linear predictor
         lp=input$Sex_Male_3*-0.112355374515625+
            input$Age_strata_70plus_3*-0.116376739756864+
            input$Structural_lung_disease_1_3*0.499509955236382+
            input$Diabetes_1_3*0.817031753398502+
            input$On_antibiotic_prophylaxis_at_end_RTX_1_3*-0.160681398815763+
            input$Cumulative_steroid_dose_3*-6.90240300279983e-05+
            input$Creatinine_at_start_RTX_3*-0.00152252874523432+
            input$IgG_at_end_RTX_3*-0.13176898846253
         
         # Determine the survival probability for 1,3,5 years 
         surv.infection=Survival(cox_infection_final)
         paste0("3-year survival probability:", round(surv.infection(3*12,lp),3))
      })
      
      output$text35 <- renderText({
         # linear predictor
         lp=input$Sex_Male_3*-0.112355374515625+
            input$Age_strata_70plus_3*-0.116376739756864+
            input$Structural_lung_disease_1_3*0.499509955236382+
            input$Diabetes_1_3*0.817031753398502+
            input$On_antibiotic_prophylaxis_at_end_RTX_1_3*-0.160681398815763+
            input$Cumulative_steroid_dose_3*-6.90240300279983e-05+
            input$Creatinine_at_start_RTX_3*-0.00152252874523432+
            input$IgG_at_end_RTX_3*-0.13176898846253
         
         # Determine the survival probability for 1,3,5 years 
         surv.infection=Survival(cox_infection_final)
         paste0("5-year survival probability: ",round(surv.infection(5*12,lp),3))
      })

   
   #####################
   # INFECTION-updated #
   #####################
  
      
      # Text string to display survival outcomes
      # Execute the "inputdata" function to save the dataframe as "data"
      output$text41 <- renderText({
         # linear predictor
         lp=input$Structural_lung_disease_1_4*0.472162258321228+
            input$Diabetes_1_4*0.633888807354171+
            input$IgG_at_12m_4*-0.0230830201387397+
            input$Lymphocyte_count_at_12mcat_1minus_4*-0.20889849559333+
            input$Creatinine_at_start_RTX_4*-0.00284474590182944
         
         # Determine the survival probability for 1,3,5 years 
         surv.infectionnew=Survival(cox_infectionnew_final)
         paste0("1-year survival probability: ",round(surv.infectionnew(1*12,lp),3))
      })
      
      output$text43 <- renderText({
         # linear predictor
         lp=input$Structural_lung_disease_1_4*0.472162258321228+
            input$Diabetes_1_4*0.633888807354171+
            input$IgG_at_12m_4*-0.0230830201387397+
            input$Lymphocyte_count_at_12mcat_1minus_4*-0.20889849559333+
            input$Creatinine_at_start_RTX_4*-0.00284474590182944
         
         
         # Determine the survival probability for 1,3,5 years 
         surv.infectionnew=Survival(cox_infectionnew_final)
         paste0("3-year survival probability:", round(surv.infectionnew(3*12,lp),3))
      })
      
      output$text45 <- renderText({
         # linear predictor
         lp=input$Structural_lung_disease_1_4*0.472162258321228+
            input$Diabetes_1_4*0.633888807354171+
            input$IgG_at_12m_4*-0.0230830201387397+
            input$Lymphocyte_count_at_12mcat_1minus_4*-0.20889849559333+
            input$Creatinine_at_start_RTX_4*-0.00284474590182944
         
         
         # Determine the survival probability for 1,3,5 years 
         surv.infectionnew=Survival(cox_infectionnew_final)
         paste0("5-year survival probability: ",round(surv.infectionnew(5*12,lp),3))
      })
   
   
}

shinyApp(ui, server)