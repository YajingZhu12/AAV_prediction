
# Updated: 26 Sept 2019 #

# Libraries #
library(devtools)
library(caret)
library(prodlim)
library(muhaz)
library(survival)
library(survminer)
library(Hmisc)
library(rms)
library(reshape2)
library(mfp)
library(rstpm2)
library(flexsurv)
library(dplyr)
library(qwraps2)
library(survminer)
library(ggfortify)
library(lsr)
library(ggcorrplot)
library(skimr)
library(purrr)
library(tidyr)
library(nonnestcox)
library(lubridate)
library(coxme)

######################

# load data #
setwd("H:\\AAVprediction\\Analysis")
lapply(c("data_relapse.RData","data_relapsenew.RData",
         "data_infection.RData","data_infectionnew.RData",
         "data_infectionSA.RData"),load,.GlobalEnv)

# check infection & sensitivity analyes for predicted survivals #
# classification based on linear predictors #
# add 70 cutoff for age 
data$Age_strata<- cut(data$Age, 
                      breaks=c(-Inf, 70, Inf), 
                      labels=c("70minus","70plus"))
data<-fastDummies::dummy_cols(data,c("Age_strata"))

data$lp_infection.org<-predict(cox_infection_final,type="lp")
data$lp_infection.sa<-predict(cox_infectionSA_final,type="lp")


data$centile_infection.org <- cut(data$lp_infection.org,
                                  breaks=quantile(data$lp_infection.org,na.rm=T,
                                          seq(0, 1, 0.333)),
                  labels=c("low","medium","high"),
                  include.lowest=TRUE)
data$centile_infection.sa <- cut(data$lp_infection.sa,
                                 breaks=quantile(data$lp_infection.sa,na.rm=T,
                                          seq(0, 1, 0.333)),
                   labels=c("SA:low","SA:medium","SA:high"),
                  include.lowest=TRUE)

table(data$centile_infection.org,data$centile_infection.sa)

# relapse and infection compariso in terms of risk categorisation #
data$lp_relapse<-predict(cox_relapse_final,type="lp")
data$centile_relapse <- cut(data$lp_relapse,
                                  breaks=quantile(data$lp_relapse,na.rm=T,
                                                  seq(0, 1, 0.333)),
                                  labels=c("relapse:low","relapse:medium","relapse:high"),
                                  include.lowest=TRUE)
data$centile_infection <- cut(data$lp_infection.org,
                                 breaks=quantile(data$lp_infection.org,na.rm=T,
                                                 seq(0, 1, 0.333)),
                                 labels=c("Infection:low","Infection:medium","Infection:high"),
                                 include.lowest=TRUE)
chisq.test(table(data$centile_relapse,data$centile_infection))

# udpate frailty model: relapse & infection #
# assume time-to-relapse and time-to-infection are correlated due to frailty
data$time.to.relapse

# generate infection indicator (if relapse happens before infection, infection is censored)
data$Infection_after_RTX<-ifelse(is.na(data$time_to_composite_1_serious_or_3_non_serious_m),0,1)

data$time.to.infection<-data$time_to_composite_1_serious_or_3_non_serious_m*30 

data$time.to.infection[is.na(data$time.to.infection)]<-as.numeric(difftime(dmy(data$Date_of_last_follow_up),
                                                                           dmy(data$Date_last_RTX),
                                                                           unit="days"))
summary(data$time.to.infection)
summary(data$time.to.relapse)
