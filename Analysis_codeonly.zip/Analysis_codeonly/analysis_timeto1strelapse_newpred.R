# Now we have extra data to improve prediction #
# Among those who have NOT had a relapse 12 months after RTX,
# do new variables help improve prediction? 

# AAV prediction
# 16 Dec 2019 
# Outcome: Time to 1st relapse: update prediction after 1 year

###### LIBRARY ######
#####################
library(devtools)
library(caret)
library(prodlim)
library(muhaz)
library(survival)
library(survminer)
library(Hmisc)
library(rms)
library(reshape2)
library(mfp)
library(rstpm2)
library(flexsurv)
library(dplyr)
library(qwraps2)
library(survminer)
library(ggfortify)
library(lsr)
library(ggcorrplot)
library(skimr)
library(purrr)
library(tidyr)
library(nonnestcox)
library(lubridate)
library(survminer)

##############################

setwd("H:\\AAVprediction\\Analysis")
load("H:\\AAVprediction\\Analysis\\data_relapse.RData")

# work on normalised data but need to re-normalise such variables #
# starting set = previously selected model + structural lung + new updates 
xpos.relapse<-match(c("Sex_Male","Age_strata_60plus","ANCA_positive_at_end_RTX_1",
                      "Concomitant_CYC_oralIS_1plus","ENT_involvement_1",
                      "Structural_lung_disease_1",
                      "Indication_for_RTX_Relapse","Steroid_dose_at_end_RTX",
                      "Creatinine_at_12m"),
                    names(data))
names(data)[xpos.relapse]
data$ANCA_positive_at_12m<-as.factor(data$ANCA_positive_at_12m)
data$B_cell_return_at_12m<-as.factor(data$B_cell_return_at_12m)

# note, analysis is run on individuals who have NOT had a relapse in 
# 12 months after the last RTX

# keep events after 12mons (if there is event) and all censored patients #
# format of time #

a<-data[dmy(data$Date_of_relapse)>(dmy(data$Date_last_RTX)+365)&
          data$Relapse_after_RTX==2 |
          data$Relapse_after_RTX==1,] 
data_12m<-a
#View(data_12m[,c("Date_of_relapse","Date_last_RTX")])
# left with 137 IDs #

data_12m<-data_12m %>%
  mutate(ANCA_chg=case_when(ANCA_positive_at_12m==0 ~ "Negative_at_12m",
                            ANCA_positive_at_12m==1 
                            & ANCA_positive_at_end_RTX_1==1 ~ "Positive_Positive",
                            ANCA_positive_at_12m==1 
                            & ANCA_positive_at_end_RTX_1==0 ~ "Negative_Positive"
  )
  )
data_12m$ANCA_chg<-as.factor(data_12m$ANCA_chg)
table(data_12m$ANCA_chg)

#need to update time.to.relapse variable : #
data_12m$X12m<-dmy(data_12m$Date_last_RTX)+365
#View(data_12m[,c("X12m","Date_of_last_follow_up","a","Date_of_relapse")])

cols<-c("Date_first_RTX","Date_last_RTX","Date_of_last_follow_up","Date_of_relapse")
data_12m[cols] <- lapply(data_12m[cols],dmy)
data_12m$time.to.relapse<-pmin(as.numeric(difftime(data_12m$Date_of_last_follow_up,
                                                   data_12m$X12m,
                                                   units="days")), 
                               as.numeric(difftime(data_12m$Date_of_relapse,
                                                   data_12m$X12m,
                                                   units="days")),na.rm=T)
#  remove negative values in the first argument: last follow-up time < 1 yr after last RTX, drop these individuals
data_12m<-data_12m[data_12m$time.to.relapse>=0,] # 130 obs

# define new predictor for updated relapse: any infection in the past year #
cols<-c("first_non_serious.infection","second_non_serious_infection",
        "third_non_serious_infection","Date_of_serious_Infection")
data_12m[cols] <- lapply(data_12m[cols],dmy)


data_12m<-data_12m %>%
  mutate(infectionin12m=as.factor(case_when(
    as.numeric(difftime(data_12m$first_non_serious.infection,
                        data_12m$Date_last_RTX,
                        units="days"))<365|
      as.numeric(difftime(data_12m$second_non_serious_infection,
                          data_12m$Date_last_RTX,
                          units="days"))<365|
      as.numeric(difftime(data_12m$third_non_serious_infection,
                          data_12m$Date_last_RTX,
                          units="days"))<365|
      as.numeric(difftime(data_12m$Date_of_serious_Infection,
                          data_12m$Date_last_RTX,
                          units="days"))<365 ~ "Yes",
    TRUE~"No")
  ))

data_12m<-data_12m %>%
  mutate(infectionin12m_1s3ns=as.factor(case_when(
    time_to_composite_1_serious_or_3_non_serious_m<=12 ~ "Yes",
    TRUE~"No")
  ))
# summary of new predictors #
summary2 <-
  # categorical #
  list(
    "Gender" =
      list("Female" = ~ qwraps2::n_perc0(.data$Sex=="Female"),
           "Male" = ~ qwraps2::n_perc0(.data$Sex =="Male")),
    "Age_strata" =
      list("60minus" = ~ qwraps2::n_perc0(.data$Age_strata == "60minus"),
           "60plus" = ~ qwraps2::n_perc0(.data$Age_strata == "60plus")),
    "Concomitant CYC or oral IS" =
      list("None" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "0"),
           "1+" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "1plus")),
    "ENT invovlement" =
      list("No" = ~ qwraps2::n_perc0(.data$ENT_involvement == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$ENT_involvement == 1)),
    "Structural lung disease" =
      list("No" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 1)),
    "Any infection during the first year" =
      list("No" = ~ qwraps2::n_perc0(.data$infectionin12m == "No"),
           "Yes" = ~ qwraps2::n_perc0(.data$infectionin12m == "Yes")),
    "1 serious/3 non-serious infections during the first year" =
      list("No" = ~ qwraps2::n_perc0(.data$infectionin12m_1s3ns == "No"),
           "Yes" = ~ qwraps2::n_perc0(.data$infectionin12m_1s3ns == "Yes")),
    "Indication for RTX" =
      list("No relapse" = ~ qwraps2::n_perc0(.data$Indication_for_RTX == "No_relapse"),
           "Relapse" = ~ qwraps2::n_perc0(.data$Indication_for_RTX == "Relapse")),
    "ANCA changes in 12m after last RTX" =
      list("Negative at end of 12m" = ~ qwraps2::n_perc0(.data$ANCA_positive_at_12m==0,na_rm=T),
           "Positive-Positive" = ~ qwraps2::n_perc0(.data$ANCA_positive_at_12m ==1&.data$ANCA_positive_at_end_RTX_1==1,na_rm=T),
           "Negative-Positive"=~ qwraps2::n_perc0(.data$ANCA_positive_at_12m ==1&.data$ANCA_positive_at_end_RTX_1==0,na_rm=T),
           "Missing"=~ sum(is.na(ANCA_positive_at_12m))
      ),
    "B-cell returns at 12m" =
      list("No" = ~ qwraps2::n_perc0(.data$B_cell_return_at_12m == 0,na_rm=T),
           "Yes" = ~ qwraps2::n_perc0(.data$B_cell_return_at_12m == 1,na_rm=T),
           "Missing"=~ sum(is.na(B_cell_return_at_12m))
      ),
    
    "Creatinine at 12m" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Creatinine_at_12m,na_rm = T)),
    "Steroid_dose_at_end_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Steroid_dose_at_end_RTX,na_rm = T)),
    
    # added due to paper foramtting #
    "ANCA positive at end RTX" =
      list("No" = ~ qwraps2::n_perc0(.data$ANCA_positive_at_end_RTX == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$ANCA_positive_at_end_RTX == 1)),
    "ANCA subtype" =
      list("Negative" = ~ qwraps2::n_perc0(.data$ANCA_subtype == "Negative"),
           "MPO" = ~ qwraps2::n_perc0(.data$ANCA_subtype =="MPO"),
           "PR3" = ~ qwraps2::n_perc0(.data$ANCA_subtype =="PR3")),
    "Creatinine at end RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Creatinine_at_end_RTX,na_rm = T)),
    "Cumulative RTX g" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_RTX_g,na_rm = T)),
    "Cumulative CYC prior to 1st RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_CYC_before_1st_RTX,na_rm = T))
  )
  
summary_table2 <- summary_table(dplyr::group_by(data_12m, as.factor(Relapse_after_RTX)), summary2)
summary_table2x <- summary_table(data_12m,summary2)
summary_table2<-cbind(summary_table2x,summary_table2)
capture.output(print(summary_table2),file="H:\\AAVprediction\\Analysis\\summary_relapse_newpred.txt")

# fast dummies for categorical variables #
data_12m<-fastDummies::dummy_cols(data_12m,c("infectionin12m",
                                             "infectionin12m_1s3ns",
                                             "ANCA_chg","B_cell_return_at_12m","ANCA_positive_at_12m"))

# descriptives for survival analysis #
km_relapsenew <- survfit(Surv(time.to.relapse/30, Relapse_after_RTX==2) ~ 1, data=data_12m)
summary(km_relapsenew)
pdf(file="H:\\AAVprediction\\Analysis\\KM_relapse_newpred.pdf")
ggsurvplot(km_relapsenew, data = data_12m,xlab="Time (Months)",palette="Black",risk.table=T)
dev.off()

# COX PH model #
# need to re-scale continuous predictors #

data2_12m<-data_12m %>% mutate_each_(list(~scale(.,center=T,scale=T) %>% as.vector),
                             vars=c("Creatinine_at_12m","Steroid_dose_at_end_RTX"
                                    ))

xpos.relapsenew<-match(c("Sex_Male","Age_strata_60plus",
                         "Concomitant_CYC_oralIS_1plus","ENT_involvement_1",
                         "Structural_lung_disease_1",
                         "Indication_for_RTX_Relapse",
                         "ANCA_chg_Negative_Positive","ANCA_chg_Positive_Positive",
                         "B_cell_return_at_12m_1",
                         "Creatinine_at_12m","Steroid_dose_at_end_RTX"
                         ),
                       names(data2_12m))


a<-paste0(paste0(names(data2_12m)[xpos.relapsenew]), collapse= "+")
b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)

cox_relapsenew.coxph<-coxph(as.formula(b), data = data2_12m,x=T) 

pdf(file="H:\\AAVprediction\\Analysis\\cox_relapse_newpred.pdf")
ggforest(cox_relapsenew.coxph, data= data2_12m,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()

# HERE: wait for Mark's confirmation on indicator #

# Shrinkage & optimism adjusted AUC, CITL etc. using bootstrapping
# with backward variable selection method:p-values >=0.8 would be dropped #
# find effect sizes for ANCA chg is similar - group them into one category: ANCA at 12m

xpos.relapsenew<-match(c("Sex_Male","Age_strata_60plus",
                         "Concomitant_CYC_oralIS_1plus","ENT_involvement_1",
                         "Structural_lung_disease_1",
                         "Indication_for_RTX_Relapse",
                         "ANCA_positive_at_12m_1",
                         "B_cell_return_at_12m_1",
                         "Creatinine_at_12m","Steroid_dose_at_end_RTX"),
                       names(data2_12m))


a<-paste0(paste0(names(data2_12m)[xpos.relapsenew]), collapse= "+")
b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)

cox_relapsenew.coxph<-coxph(as.formula(b), data = data2_12m,x=T) 
cox_relapsenew.cph<-cph(as.formula(b),data=data2_12m,x=T,y=T,surv=T,time.inc = 1)

# bootstrap results #
boot_results<-matrix(nrow=10,ncol=2)
pos<-1
for (p in c(4,4.5,5,6,6.5,7,7.5,8,8.5,9)) {
  set.seed(12345) # to ensure reproducibility
  boot_relapse<-validate(cox_relapsenew.cph,method="boot",B=1000,
                         bw=T,rule="p",type="individual",
                         sls=p/10)
  boot_relapse<-rbind(c((boot_relapse[1,1:3]+1)/2,
                        (boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2,
                        (boot_relapse[1,1]+1)/2-((boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2),
                        boot_relapse[1,6]),
                      boot_relapse)
  rownames(boot_relapse)[1]<-"c-index"
  colnames(boot_relapse)<-c("Apparent","BS_training","BS_test","Optimism",
                            "Optimism-corrected","rep")
  boot_results[pos,1]<-boot_relapse[4,5] # index-corrected slope
  boot_results[pos,2]<-boot_relapse[1,5] # index-corrected c-index
  pos<-pos+1
  
}
boot_results
capture.output(boot_results,
               file="H:\\AAVprediction\\Analysis\\relapsenewpred_boot_results.txt")

p<-0.4
set.seed(12345) # to ensure reproducibility
boot_relapse<-validate(cox_relapsenew.cph,method="boot",B=1000,
                       bw=T,rule="p",type="individual",
                       sls=p)
boot_relapse[1:7,1:6]

# Convert Dxy to c-index
boot_relapse<-rbind(c((boot_relapse[1,1:3]+1)/2,
                      (boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2,
                      (boot_relapse[1,1]+1)/2-((boot_relapse[1,2]+1)/2-(boot_relapse[1,3]+1)/2),
                      boot_relapse[1,6]),
                    boot_relapse)
rownames(boot_relapse)[1]<-"c-index"
colnames(boot_relapse)<-c("Apparent","BS_training","BS_test","Optimism",
                          "Optimism-corrected","rep")
boot_relapse
capture.output(boot_relapse,file="H:\\AAVprediction\\Analysis\\relapse_newreduced_internal.txt")

# retrieved 5 factors in the final model #
xpos.relapsenew<-match(c("ENT_involvement_1",
                         "Indication_for_RTX_Relapse","ANCA_positive_at_12m_1",
                         "Creatinine_at_12m","Steroid_dose_at_end_RTX"),
                       names(data2_12m))
names(data2_12m)[xpos.relapsenew]

a<-paste0(paste0(names(data2_12m)[xpos.relapsenew]), collapse= "+")
b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)

cox_relapsenew_reduced.coxph<-coxph(as.formula(b), data= data2_12m,x=T)
cox_relapsenew_reduced.cph<-cph(as.formula(b), data= data2_12m,
                                x=T,y=T,surv=T,time.inc = 1)

pdf(file="H:\\AAVprediction\\Analysis\\cox_relapsenew_reduced.pdf")
ggforest(cox_relapsenew_reduced.coxph, data= data2_12m,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()

# Test for PH assumption - residual distribution #
cox.zph(cox_relapsenew_reduced.coxph)
pdf(file="H:\\AAVprediction\\Analysis\\cox_relapsenew_reduced_PHtest.pdf")
ggcoxzph(cox.zph(cox_relapsenew_reduced.coxph),font.main=5,font.x=6,font.y=5,
         font.xtickslab=6,font.ytickslab=6)
dev.off()


# Shrink coefficients to improve prediction #
shrinkage.factor<-boot_relapse["Slope","Optimism-corrected"]
coef_relapsenew_reduced<- data.frame(Original = coef(cox_relapsenew_reduced.coxph),
                                  Shrunk.BS=c(coef(cox_relapsenew_reduced.coxph) * boot_relapse["Slope","Optimism-corrected"]))
capture.output(round(coef_relapsenew_reduced, 3),file="H:\\AAVprediction\\Analysis\\relapsenewnew_reduced_internal_shrunken.txt")

# PI & C-index for reduced vs shrunk model#
pred_LP <- predict(cox_relapsenew_reduced.coxph,type="lp",reference="sample")
summary(cox_relapsenew_reduced.coxph)$concordance[1]
summary(cox_relapsenew_reduced.coxph)$concordance[1]-(1.96*summary(cox_relapsenew_reduced.coxph)$concordance[2])
summary(cox_relapsenew_reduced.coxph)$concordance[1]+(1.96*summary(cox_relapsenew_reduced.coxph)$concordance[2])
# so apparent c-index= 0.682 [95%CI 0.608, 0.756]


###########################################################

# calibrate the shrunken model (BS) using bootstrap samples #
# how well is the model at discrimination #
coef_relapsenew_reduced <- tibble::rownames_to_column(coef_relapsenew_reduced,"X")
coef_relapsenew_reduced

# Final model #
# calibrate the final model (horizon=1-6 years,
# present both uncalibrate & calibrated models) #

horizon<-12*seq(1,6,1)

for (i in 1:length(horizon)){
  tempmodel<- cph(cox_relapsenew_reduced.cph$sformula, data=data2_12m,
                  x=T,y=T,surv=T,
                  time.inc=horizon[i])
  
  set.seed(12345) # to ensure reproducibility
  #cal<-calibrate(tempmodel,u=horizon[i],B=1000,maxdim=10) # to add on smoothness
  cali_relapsenew<-calibrate(tempmodel,u=horizon[i],m=130/5,
                          cmethod="KM",method="boot",B=1000)
  fpath<-paste0("H:\\AAVprediction\\Analysis\\calib_relapsenew",horizon[i]/12, 
                " yr.pdf")
  pdf(file=fpath)
  print(plot(cali_relapsenew,subtitles=F,ylab=paste0("Observed survival (KM)",horizon[i]/12, " years"),   
             xlab=paste0("Predicted survival",horizon[i]/12, " years"),
             xlim=c(0,1),ylim=c(0,1),
             cex.lab=1,cex=0.5,mgp=c(1.2,0.1,0.1),
             par.corrected=list(col="red", lty=1, lwd=2, pch=4))+
          abline(0, 1, lty=2))
  dev.off()
}

# prepare for the offset model using shrunk coefficients 
# raise it to original scale #
# display final shrunk model #
cox_relapsenew_reduced_scaleback.coxph<-coxph(as.formula(b),data=data_12m,x=T)
cox_relapsenew_reduced_scaleback.cph<-cph(as.formula(b),data=data_12m,
                                       x=T,y=T,surv=T,time.inc=T)
coef_relapsenew_reduced_scaleback<- data.frame(Original = coef(cox_relapsenew_reduced_scaleback.coxph),
                                            Shrunk.BS=c(coef(cox_relapsenew_reduced_scaleback.coxph) * shrinkage.factor))
coef_relapsenew_reduced_scaleback <- tibble::rownames_to_column(coef_relapsenew_reduced_scaleback,"X")

a<-paste0(coef_relapsenew_reduced_scaleback[1,1],"*",
          coef_relapsenew_reduced_scaleback[1,3])
for (i in (2:nrow(coef_relapsenew_reduced_scaleback))){
  a0<-paste0(coef_relapsenew_reduced_scaleback[i,1],"*",
             coef_relapsenew_reduced_scaleback[i,3])
  a<-paste0(c(a,a0),collapse = "+")
}

final_relapsenew<-paste0("Surv(time.to.relapse/30, relapse_after_RTX==2)","~",a)
final_relapsenew

# use the final shrunken model for nomogram #
a<-paste0(coef_relapsenew_reduced_scaleback[1,1],"*",
          coef_relapsenew_reduced_scaleback[1,3])
for (i in (2:nrow(coef_relapsenew_reduced_scaleback))){
  a0<-paste0(coef_relapsenew_reduced_scaleback[i,1],"*",
             coef_relapsenew_reduced_scaleback[i,3])
  a<-paste0(c(a,a0),collapse = "+")
}
a<-paste0("offset(",a,")")

b<-paste0("Surv(time.to.relapse/30, Relapse_after_RTX==2)","~",a)
dd <- datadist(data_12m)
options(datadist = 'dd')
model<-cph(as.formula(b),data=data_12m,x=T,y=T,surv=T,time.inc = 1)

cox_relapsenew_final<-cox_relapsenew_reduced_scaleback.cph
cox_relapsenew_final$coefficients<-coef_relapsenew_reduced_scaleback[[3]]
cox_relapsenew_final$sformula<-cox_relapsenew_reduced_scaleback.cph$sformula
cox_relapsenew_final$linear.predictors<-model$linear.predictors
cox_relapsenew_final$surv<-model$surv
cox_relapsenew_final$surv.summary<-model$surv.summary
cox_relapsenew_final$std.err<-model$std.err # standard errors of estimate log-log survival
cox_relapsenew_final$residuals<-model$residuals #martingale residuals
cox_relapsenew_final$loglik[2]<-model$loglik # loglike=initial& final ll
cox_relapsenew_final$center<-mean(model$linear.predictors) # overall mean of Xbeta

# Plot of separation of KM curve across 2/3 groups at centiles of lp #
data_12m$pred_LP <- predict(cox_relapsenew_final,type="lp")
data_12m$centile_LP <- cut(data_12m$pred_LP,breaks=quantile(data_12m$pred_LP,na.rm=T,
                                          seq(0, 1, 0.33)),
                  labels=c(1:3),include.lowest=TRUE)

# Graph the KM curves in the 2/3 risk groups to visually assess separation #
survfit(Surv(time.to.relapse/30, Relapse_after_RTX==2)~centile_LP,
        data=data_12m)

pdf(file="H:\\AAVprediction\\Analysis\\KM_relapsenew_separationbygroup_shrunk_3grp.pdf")
ggsurvplot(survfit(Surv(time.to.relapse/30, Relapse_after_RTX==2)~centile_LP,
                   data=data_12m),data=data_12m, risk.table=T,risk.table.col = "centile_LP",
           legend.labs = c("Low risk", "Medium risk","High risk"),
           xlab = "Time in months",
           break.x.by=12,
           surv.median.line = "hv",
           ggtheme = theme_bw() 
)
dev.off()

# Nomograms #
surv.relapsenew<-Survival(cox_relapsenew_final)
nomo_relapsenew<-nomogram(cox_relapsenew_final,
                       fun=list(function(x) surv.relapsenew(1*12,x),
                                function(x) surv.relapsenew(3*12,x),
                                function(x) surv.relapsenew(5*12,x)),
                       funlabel=c("1 year survival prob.",
                                  "3 year survival prob.",
                                  "5 year survival prob."),
                       lp=F
)
pdf("H:\\AAVprediction\\Analysis\\nomogram_relapsenew.pdf")
plot(nomo_relapsenew,cex.axis=0.3,xfrac=0.6,cex.var=0.7)
dev.off()

# save important data #
save(cox_relapsenew_final,final_relapsenew,data2_12m,file="H:\\AAVprediction\\Analysis\\data_relapsenew.RData")
