# AAV prediction
# 17 Sept 2019 
# Outcome: Time to 1st infection
# Sensitivity analysis for infection model #
# Treat individuals with relapse BEFORE infection as censored.

###### LIBRARY ######
#####################

library(devtools)
library(caret)
library(prodlim)
library(muhaz)
library(survival)
library(survminer)
library(Hmisc)
library(rms)
library(reshape2)
library(mfp)
library(rstpm2)
library(flexsurv)
library(dplyr)
library(qwraps2)
library(survminer)
library(ggfortify)
library(lsr)
library(ggcorrplot)
library(skimr)
library(purrr)
library(tidyr)
library(nonnestcox)
library(lubridate)

######################

##################################
# Data preparation for infection #
##################################

setwd("H:\\AAVprediction\\Analysis")
load("H:\\AAVprediction\\Analysis\\data_relapse.RData")

# compute time-to-infection in days #
# View(data[,c("time_to_composite_1_serious_or_3_non_serious_m","non_serious_infection_after_RTX",
#              "Serious_infection_after_RTX","third_non_serious_infection")])

# create event indicator#
data$Infection_after_RTX<-ifelse(is.na(data$time_to_composite_1_serious_or_3_non_serious_m),0,1)

data$time.to.infection<-data$time_to_composite_1_serious_or_3_non_serious_m*30 

data$time.to.infection[is.na(data$time.to.infection)]<-as.numeric(difftime(dmy(data$Date_of_last_follow_up),
                                                                           dmy(data$Date_last_RTX),
                                                                           unit="days"))

#View(data[,c("time_to_composite_1_serious_or_3_non_serious_m","time.to.infection","infection_after_RTX")])

# SA: change infection indicator to 0 for individuals who had a relapse before infection event #
nrow_relapse_infection<-nrow(data[data$Infection_after_RTX==1&data$Relapse_after_RTX==2&
            data$time.to.relapse<data$time.to.infection,
          c("time.to.relapse","time.to.infection")])
nrow_infection_relapse<-nrow(data[data$Infection_after_RTX==1&data$Relapse_after_RTX==2&
                                    data$time.to.infection<data$time.to.relapse,
                                  c("time.to.relapse","time.to.infection")])

table(data$Infection_after_RTX) # 88 events

# SA comes in here:
data$Infection_after_RTX[data$Infection_after_RTX==1&data$Relapse_after_RTX==2&
                               data$time.to.relapse<data$time.to.infection]<-0

table(data$Infection_after_RTX) # 60 events

# remove individuals where last follow-up date <= last RTX date #
data<-data[!(data$time.to.infection<0.00001),] # left with 147 IDs


# make age categorical as a stratification factor #
data[,c("Age_strata","Age_strata_60minus","Age_strata_60plus")]<-NULL
data$Age_strata<- cut(data$Age, 
                      breaks=c(-Inf, 70, Inf), 
                      labels=c("70minus","70plus"))


# shorten covariate names for easy display #
names(data)[26]<-c("Total_lymphocyte_count_at_end_RTX")


# identify categorical predictors & age variables #
data[,c("Sex","Indication_for_RTX","Clinical_subtype",
        "ANCA_subtype","ENT_involvement","Concomitant_CYC",
        "Concomitant_oral_IS","Prev_RTX_ever","Off_steroids_at_end_RTX",
        "ANCA_positive_at_end_RTX","Future_IVIG",
        "On_antibiotic_prophylaxis_at_end_RTX","Number_of_serious_infections_during_RTX",
        "Infection_after_RTX","Relapse_after_RTX","Concomitant_CYC_oralIS",
        "Age_strata","Structural_lung_disease","Diabetes")] <- lapply(data[,c("Sex","Indication_for_RTX","Clinical_subtype",
                                                                              "ANCA_subtype","ENT_involvement","Concomitant_CYC",
                                                                              "Concomitant_oral_IS","Prev_RTX_ever","Off_steroids_at_end_RTX",
                                                                              "ANCA_positive_at_end_RTX","Future_IVIG",
                                                                              "On_antibiotic_prophylaxis_at_end_RTX",
                                                                              "Number_of_serious_infections_during_RTX",
                                                                              "Infection_after_RTX",
                                                                              "Relapse_after_RTX","Concomitant_CYC_oralIS","Age_strata","Structural_lung_disease","Diabetes")],factor)  

indices_inf<-match(c("time.to.infection","Infection_after_RTX","Sex","Age_strata",
                     "Structural_lung_disease","Diabetes","Concomitant_CYC_oralIS",
                     "On_antibiotic_prophylaxis_at_end_RTX",
                     "Cumulative_CYC_before_1st_RTX","Cumulative_steroid_dose",
                     "Cumulative_RTX_g","Steroid_dose_at_end_RTX",
                     "Creatinine_at_start_RTX","Nadir_IgG_during_RTX","IgG_at_end_RTX",
                     "Total_lymphocyte_count_at_end_RTX","Age"),names(data))
names(data[indices_inf]) #17-1 predictors (age/age strata just one!)

# Prepare summary statistics for table #
summarydata<-data[indices_inf] %>% group_by(Infection_after_RTX) %>% skim() 
capture.output(print(summarydata),file="H:\\AAVprediction\\Analysis\\summary_infection.txt")

summary1 <-
  # categorical #
  list(
    "Gender" =
      list("Female" = ~ qwraps2::n_perc0(.data$Sex=="Female"),
           "Male" = ~ qwraps2::n_perc0(.data$Sex =="Male")),
    "Age_strata" =
      list("70minus" = ~ qwraps2::n_perc0(.data$Age_strata == "70minus"),
           "70plus" = ~ qwraps2::n_perc0(.data$Age_strata == "70plus")),
    "Structural_lung_disease" =
      list("No" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$Structural_lung_disease == 1)),
    "Diabetes" =
      list("No" = ~ qwraps2::n_perc0(.data$Diabetes == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$Diabetes == 1)),
    "Concomitant CYC or oral IS" =
      list("None" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "0"),
           "1+" = ~ qwraps2::n_perc0(.data$Concomitant_CYC_oralIS == "1plus")),
    "On_antibiotic_prophylaxis_at_end_RTX"=
      list("No" = ~ qwraps2::n_perc0(.data$On_antibiotic_prophylaxis_at_end_RTX == 0),
           "Yes" = ~ qwraps2::n_perc0(.data$On_antibiotic_prophylaxis_at_end_RTX == 1)),
    "Age" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Age)),
    # this variable has 1 missing #
    "Cumulative CYC prior to 1st RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_CYC_before_1st_RTX,na_rm = T)),
    
    # this variable has missing value, but only for relapse, complete data #
    "Cumulative steroid dose (over 2 years)" = 
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_steroid_dose,na_rm = T)),
    "Cumulative RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Cumulative_RTX_g,na_rm = T)),
    "Steroid dose at end RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Steroid_dose_at_end_RTX,na_rm = T)),
    "Creatinine at start RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Creatinine_at_start_RTX,na_rm = T)),
    "Nadir_IgG_during_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Nadir_IgG_during_RTX,na_rm = T)),
    "IgG_at_end_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$IgG_at_end_RTX,na_rm = T)),
    
    # this variable has 4 missing values #
    "Total_lymphocyte_count_at_end_RTX" =
      list("Median (Q1,Q3)" = ~ qwraps2::median_iqr(.data$Total_lymphocyte_count_at_end_RTX,na_rm = T,
                                                    show_n = "never"),
           "Missing"=~ sum(is.na(Total_lymphocyte_count_at_end_RTX)))
  )

summary_table1 <- summary_table(data,summary1)
summary_table2 <- summary_table(dplyr::group_by(data, Infection_after_RTX), summary1)
summary_table<-cbind(summary_table1,summary_table2)
capture.output(print(summary_table),file="H:\\AAVprediction\\Analysis\\summary_infection.txt")


# Overlapped histograms for all numeric preditors #
data$Infection_after_RTX<-factor(data$Infection_after_RTX,
                                 levels=c("0","1"),
                                 labels=c("No","Yes"))

names(data[indices_inf])

# 9= 9 continuous variables where relapse label needs to be repeated on #
pdf(file="H:\\AAVprediction\\Analysis\\dist_infection_contvars.pdf")
data[indices_inf[-c(1:2)]] %>%
  keep(is.numeric) %>% 
  gather() %>% 
  ggplot(aes(value,fill=rep(data$Infection_after_RTX, 9))) +
  facet_wrap(~ key, scales = "free",ncol = 3) +
  geom_histogram(alpha=0.5, position="identity")+
  labs(fill = "Infectoin after RTX") +
  theme(text = element_text(size=8))
dev.off()

#create dummies for all categorical predictors#
data<-fastDummies::dummy_cols(data,c("Age_strata","Structural_lung_disease","Diabetes","Concomitant_CYC_oralIS",
                                     "On_antibiotic_prophylaxis_at_end_RTX"))

data$Infection_after_RTX<-as.numeric(data$Infection_after_RTX)

#  describe time-to-1st infection #
km_infection <- survfit(Surv(time.to.infection/30, Infection_after_RTX==2) ~ 1, data=data)
summary(km_infection)
pdf(file="H:\\AAVprediction\\Analysis\\KM_infection.pdf")
ggsurvplot(km_infection, data = data,xlab="Time (Months)",palette="Black",risk.table=T)
dev.off()

################
# COX PH model #
################

# add predictors: age strata (to replace raw age, indicator for infection have happened or not before infection
data$Infection_after_RTX<-as.numeric(data$Infection_after_RTX)
table(data$Infection_after_RTX) #2=event

# quick correlation check find that cor(IgG_at_end_RTX, Nadir_IgG_during_RTX) =0.9 , 
# drop Nadir_igG_during_RTX #


# Normalise all continuous predictors (7 for infection) #
data2<-data %>% mutate_each_(list(~scale(.,center=T,scale=T) %>% as.vector),
                             vars=c("Cumulative_CYC_before_1st_RTX","Cumulative_steroid_dose",
                                    "Cumulative_RTX_g","Steroid_dose_at_end_RTX",
                                    "Creatinine_at_start_RTX","IgG_at_end_RTX",
                                    "Total_lymphocyte_count_at_end_RTX"))

# log-transform all continuous predictors (7 for infection) #
data3<-data %>% mutate_each_(list(~log(.+0.5) %>% as.vector),
                             vars=c("Cumulative_CYC_before_1st_RTX","Cumulative_steroid_dose",
                                    "Cumulative_RTX_g","Steroid_dose_at_end_RTX",
                                    "Creatinine_at_start_RTX","IgG_at_end_RTX",
                                    "Total_lymphocyte_count_at_end_RTX"))

xpos.infection<-match(c("Sex_Male","Age_strata_70plus","Structural_lung_disease_1","Diabetes_1",
                        "Concomitant_CYC_oralIS_1plus","On_antibiotic_prophylaxis_at_end_RTX_1",
                        "Cumulative_CYC_before_1st_RTX",
                        "Cumulative_steroid_dose","Cumulative_RTX_g","Steroid_dose_at_end_RTX",
                        "Creatinine_at_start_RTX","IgG_at_end_RTX",
                        "Total_lymphocyte_count_at_end_RTX"),
                      names(data))
names(data)[xpos.infection]


a<-paste0(paste0(names(data)[xpos.infection]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)

# compare log-transformed vs normalised model: which is better? log-transformed#
infection1<-coxph(as.formula(b), data = data2,x=T) # normalised
infection2<-coxph(as.formula(b), data = data3,x=T) # log-transformed

pdf(file="H:\\AAVprediction\\Analysis\\cox_infection_normalised.pdf")
ggforest(infection1, data= data2,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()

pdf(file="H:\\AAVprediction\\Analysis\\cox_infection_logtransformed.pdf")
ggforest(infection2, data= data3,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()


# partial likelihood ratio test for two transformations #
plrtest(infection1,infection2,nested=F) # p=0.237

# compared c-index #
infection1$concordance[6]/infection2$concordance[6] # normalised wins!


# Check correlation among predictors: all seems fine #
lapply(data2[xpos.infection],class)
corr.x<-cor(data2[xpos.infection],use="complete.obs")
pdf(file="H:\\AAVprediction\\Analysis\\corr_infectionX_normalised.pdf")
ggcorrplot(corr.x, hc.order = TRUE, type = "lower",
           outline.col = "white", tl.cex = 6,lab=T,lab_size=2)
dev.off()

##############################################################################

# Use internal calibration to select the reduced model #
# use original data are fine! #

rm(data3)

# run the model using normalised data #
xpos.infection<-match(c("Sex_Male","Age_strata_70plus","Structural_lung_disease_1","Diabetes_1",
                        "Concomitant_CYC_oralIS_1plus","On_antibiotic_prophylaxis_at_end_RTX_1",
                        "Cumulative_CYC_before_1st_RTX",
                        "Cumulative_steroid_dose","Cumulative_RTX_g","Steroid_dose_at_end_RTX",
                        "Creatinine_at_start_RTX","IgG_at_end_RTX",
                        "Total_lymphocyte_count_at_end_RTX"),
                      names(data))
names(data)[xpos.infection]


# coxph model #

a<-paste0(paste0(names(data)[xpos.infection]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)
cox_infection.cph<- cph(as.formula(b), data=data2,x=T,y=T,surv=T)
cox_infection.coxph<- coxph(as.formula(b), data=data2)

pdf(file="H:\\AAVprediction\\Analysis\\cox_infection_SA.pdf")
ggforest(cox_infection.coxph, data= data2,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()

# Shrinkage & optimism adjusted AUC, CITL etc. using bootstrapping
# with backward variable selection method:
# note: run on data2 due to variable scales for better protection# 
# cox_infection_norm.cph<- cph(as.formula(b), data=data22,x=T,y=T,surv=T) # this is just backup

boot_results<-matrix(nrow=10,ncol=2)
pos<-1
for (p in c(3,4,5,6,6.5,7,7.5,8,8.5,9)) {
  set.seed(12345) # to ensure reproducibility
  boot_infection<-validate(cox_infection.cph,method="boot",B=1000,
                           bw=T,rule="p",type="individual",
                           sls=p/10)
  boot_infection<-rbind(c((boot_infection[1,1:3]+1)/2,
                          (boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2,
                          (boot_infection[1,1]+1)/2-((boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2),
                          boot_infection[1,6]),
                        boot_infection)
  rownames(boot_infection)[1]<-"c-index"
  colnames(boot_infection)<-c("Apparent","BS_training","BS_test","Optimism",
                              "Optimism-corrected","rep")
  boot_results[pos,1]<-boot_infection[4,5] # index-corrected slope
  boot_results[pos,2]<-boot_infection[1,5] # index-corrected c-index
  pos<-pos+1
}
boot_results

# bootstrap for infection: #
set.seed(12345) # to ensure reproducibility
p<-0.5
boot_infection<-validate(cox_infection.cph,method="boot",B=1000,
                         bw=T,rule="p",type="individual",
                         sls=p)
boot_infection<-rbind(c((boot_infection[1,1:3]+1)/2,
                        (boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2,
                        (boot_infection[1,1]+1)/2-((boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2),
                        boot_infection[1,6]),
                      boot_infection)
rownames(boot_infection)[1]<-"c-index"
colnames(boot_infection)<-c("Apparent","BS_training","BS_test","Optimism",
                            "Optimism-corrected","rep")
capture.output(boot_infection,file="H:\\AAVprediction\\Analysis\\infection_reduced_internal_SA.txt")

# retrieved 8 factors in the final model #
xpos.infection<-match(c("Sex_Male","Structural_lung_disease_1",
                        "Diabetes_1","Concomitant_CYC_oralIS_1plus",
                        "Cumulative_steroid_dose","Steroid_dose_at_end_RTX",
                        "IgG_at_end_RTX","Total_lymphocyte_count_at_end_RTX"),
                      names(data2))
names(data2)[xpos.infection]

a<-paste0(paste0(names(data2)[xpos.infection]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)

cox_infection_reduced.coxph<-coxph(as.formula(b), data=data2,x=T)
cox_infection_reduced.cph<-cph(as.formula(b), data=data2,x=T,y=T,surv=T,time.inc=1)

# Test for PH assumption - residual distribution #
cox.zph(cox_infection_reduced.coxph)
pdf(file="H:\\AAVprediction\\Analysis\\cox_infection_reduced_PHtest_SA.pdf")
ggcoxzph(cox.zph(cox_infection_reduced.coxph),font.main=5,font.x=6,font.y=5,
         font.xtickslab=6,font.ytickslab=6)
dev.off()

##############################################
# Sex_Male & Concomitant_CYC violates PH assumption
# checks by removing these two variables #

xpos.infection2<-match(c("Structural_lung_disease_1",
                         "Diabetes_1",
                         "Cumulative_steroid_dose","Steroid_dose_at_end_RTX",
                         "IgG_at_end_RTX","Total_lymphocyte_count_at_end_RTX"),
                       names(data2))
names(data2)[xpos.infection2]

a<-paste0(paste0(names(data2)[xpos.infection2]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)

cox_infection_reduced2.coxph<-coxph(as.formula(b), data=data2,x=T)

cox.zph(cox_infection_reduced2.coxph)
pdf(file="H:\\AAVprediction\\Analysis\\cox_infection_reduced2_PHtest_SA.pdf")
ggcoxzph(cox.zph(cox_infection_reduced2.coxph),font.main=5,font.x=6,font.y=5,
         font.xtickslab=6,font.ytickslab=6)
dev.off()

###############################################

# the reduced2 model is now officially the better reduced model #
xpos.infection<-xpos.infection2
cox_infection_reduced.coxph<-coxph(as.formula(b), data=data2,x=T)
cox_infection_reduced.cph<-cph(as.formula(b), data=data2,x=T,y=T,surv=T,time.inc=1)

pdf(file="H:\\AAVprediction\\Analysis\\cox_infection_reduced_SA.pdf")
ggforest(cox_infection_reduced.coxph, data=data2,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
dev.off()


#########################
# SA SA Treat individuals with relapse event BEFORE infection as censored  #
# data2.SA<-data2
# data2.SA$Infection_after_RTX[data$Infection_after_RTX==2&data$Relapse_after_RTX==2&
#                            data$time.to.relapse<data$time.to.infection]<-1
# 
# table(data2.SA$Infection_after_RTX) # 60 events
# 
# cox_infection_reduced_SA.coxph<-coxph(as.formula(b), data=data2.SA,x=T)
# cox_infection_reduced_SA.cph<-cph(as.formula(b), data=data2.SA,x=T,y=T,surv=T,time.inc=1)
# 
# pdf(file="H:\\AAVprediction\\Analysis\\cox_infection_reduced_SA.pdf")
# ggforest(cox_infection_reduced_SA.coxph, data=data2.SA,cpositions = c(0.01, 0.3, 0.41),fontsize = 0.5)
# dev.off()

###################################

# bootstrap for infection with the further reduced 8-para model #
set.seed(12345) # to ensure reproducibility
boot_infection<-validate(cox_infection_reduced.cph,method="boot",B=1000)
boot_infection<-rbind(c((boot_infection[1,1:3]+1)/2,
                        (boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2,
                        (boot_infection[1,1]+1)/2-((boot_infection[1,2]+1)/2-(boot_infection[1,3]+1)/2),
                        boot_infection[1,6]),
                      boot_infection)
rownames(boot_infection)[1]<-"c-index"
colnames(boot_infection)<-c("Apparent","BS_training","BS_test","Optimism",
                            "Optimism-corrected","rep")
capture.output(boot_infection,file="H:\\AAVprediction\\Analysis\\infection_reduced_internal_SA.txt")

# Shrink coefficients to improve prediction #
shrinkage.factor<-boot_infection["Slope","Optimism-corrected"]
coef_infection_reduced<- data.frame(Original = coef(cox_infection_reduced.coxph),
                                    Shrunk.BS=c(coef(cox_infection_reduced.coxph) * boot_infection["Slope","Optimism-corrected"]))
capture.output(round(coef_infection_reduced, 3),file="H:\\AAVprediction\\Analysis\\infectionnew_reduced_internal_shrunken_SA.txt")

# PI & C-index for reduced vs shrunk model#
pred_LP <- predict(cox_infection_reduced.coxph,type="lp",reference="sample")
summary(cox_infection_reduced.coxph)$concordance[1]
summary(cox_infection_reduced.coxph)$concordance[1]-(1.96*summary(cox_infection_reduced.coxph)$concordance[2])
summary(cox_infection_reduced.coxph)$concordance[1]+(1.96*summary(cox_infection_reduced.coxph)$concordance[2])
# so apparent c-index= 0.677 [95%CI 0.615, 0.740]

###########################################################
# calibrate the shrunken model (vanH) using bootstrap samples #
# how well is the model at discrimination #
coef_infection_reduced <- tibble::rownames_to_column(coef_infection_reduced,"X")
coef_infection_reduced

# Final model #
# calibrate the final model (horizon=1-6 years,
# present both uncalibrate & calibrated models) #
horizon<-12*seq(1,6,1)

for (i in 1:length(horizon)){
  tempmodel<- cph(cox_infection_reduced.cph$sformula, data=data2,
                  x=T,y=T,surv=T,
                  time.inc=horizon[i])
  
  set.seed(12345) # to ensure reproducibility
  #cal<-calibrate(tempmodel,u=horizon[i],B=1000,maxdim=10) # to add on smoothness
  cali_infection<-calibrate(tempmodel,u=horizon[i],m=147/5,
                            cmethod="KM",method="boot",B=1000)
  fpath<-paste0("H:\\AAVprediction\\Analysis\\calib_infection_SA",horizon[i]/12, 
                " yr.pdf")
  pdf(file=fpath)
  lims<-min(attributes(cali_infection)$predicted)
  print(plot(cali_infection,subtitles=F,ylab=paste0("Observed survival (KM)",horizon[i]/12, " years"),   
             xlab=paste0("Predicted survival",horizon[i]/12, " years"),
             xlim=c(0,1),ylim=c(0,1),
             cex.lab=1,cex=0.5,mgp=c(1.2,0.1,0.1),
             par.corrected=list(col="red", lty=1, lwd=2, pch=4))+
          abline(0, 1, lty=2))
  dev.off()
}


# prepare for the offset model using shrunk coefficients 
# raise it to original scale #
# display final shrunk model #

a<-paste0(paste0(names(data)[xpos.infection]), collapse= "+")
b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)

cox_infection_reduced_scaleback.coxph<-coxph(as.formula(b),data=data,x=T)
cox_infection_reduced_scaleback.cph<-cph(as.formula(b),data=data,
                                         x=T,y=T,surv=T,time.inc=T)
coef_infection_reduced_scaleback<- data.frame(Original = coef(cox_infection_reduced_scaleback.coxph),
                                              Shrunk.BS=c(coef(cox_infection_reduced_scaleback.coxph) * shrinkage.factor))
coef_infection_reduced_scaleback <- tibble::rownames_to_column(coef_infection_reduced_scaleback,"X")

a<-paste0(coef_infection_reduced_scaleback[1,1],"*",
          coef_infection_reduced_scaleback[1,3])
for (i in (2:nrow(coef_infection_reduced_scaleback))){
  a0<-paste0(coef_infection_reduced_scaleback[i,1],"*",
             coef_infection_reduced_scaleback[i,3])
  a<-paste0(c(a,a0),collapse = "+")
}

final_infection<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)
final_infection

# use the final shrunken model for nomogram #
a<-paste0(coef_infection_reduced_scaleback[1,1],"*",
          coef_infection_reduced_scaleback[1,3])
for (i in (2:nrow(coef_infection_reduced_scaleback))){
  a0<-paste0(coef_infection_reduced_scaleback[i,1],"*",
             coef_infection_reduced_scaleback[i,3])
  a<-paste0(c(a,a0),collapse = "+")
}
a<-paste0("offset(",a,")")

b<-paste0("Surv(time.to.infection/30, Infection_after_RTX==2)","~",a)
dd <- datadist(data)
options(datadist = 'dd')
model<-cph(as.formula(b),data=data,x=T,y=T,surv=T,time.inc = 1)

cox_infection_final<-cox_infection_reduced_scaleback.cph
cox_infection_final$coefficients<-coef_infection_reduced_scaleback[[3]]
cox_infection_final$sformula<-cox_infection_reduced_scaleback.cph$sformula
cox_infection_final$linear.predictors<-model$linear.predictors
cox_infection_final$surv<-model$surv
cox_infection_final$surv.summary<-model$surv.summary
cox_infection_final$std.err<-model$std.err # standard errors of estimate log-log survival
cox_infection_final$residuals<-model$residuals #martingale residuals
cox_infection_final$loglik[2]<-model$loglik # loglike=initial& final ll
cox_infection_final$center<-mean(model$linear.predictors) # overall mean of Xbeta

# Plot of separation of KM curve across 2/3 groups at centiles of lp #
pred_LP <- predict(cox_infection_final,type="lp")
centile_LP <- cut(pred_LP,breaks=quantile(pred_LP,na.rm=T,
                                          seq(0, 1, 0.333)),
                  labels=c(1:3),include.lowest=TRUE)

# Graph the KM curves in the 2/3 risk groups to visually assess separation #
pdf(file="H:\\AAVprediction\\Analysis\\KM_infection_separationbygroup_shrunk_3grp_SA.pdf")
plot(survfit(Surv(time.to.infection/30, Infection_after_RTX==2)~centile_LP,
             data=data),
     main="Kaplan-Meier survival estimates",
     xlab="Analysis time (months)",col=c(1:3))
legend("topright",c("group=1","group=2","group=3"),col=c(1:3),
       lty=1,bty="n")
dev.off()

# Nomograms #
surv.infection<-Survival(cox_infection_final)
nomo_infection<-nomogram(cox_infection_final,
                         fun=list(function(x) surv.infection(1*12,x),
                                  function(x) surv.infection(3*12,x),
                                  function(x) surv.infection(5*12,x)),
                         funlabel=c("1 year survival prob.",
                                    "3 year survival prob.",
                                    "5 year survival prob."),
                         lp=F
)
pdf("H:\\AAVprediction\\Analysis\\nomogram_infection_SA.pdf")
plot(nomo_infection,cex.axis=0.3,xfrac=0.6,cex.var=0.7)
dev.off()

#save data#
cox_infectionSA_final<-cox_infection_final
final_infectionSA<-final_infection
save(cox_infectionSA_final,final_infectionSA,
     file="H:\\AAVprediction\\Analysis\\data_infectionSA.RData")



